# 🎨 Plugin Màu Sắc Website - Color & Theme Customizer Pro

[![WordPress Plugin](https://img.shields.io/badge/WordPress-Plugin%20Ready-blue.svg?logo=wordpress)](https://wordpress.org)
[![Version](https://img.shields.io/badge/Version-1.0.0-success.svg)]()
[![License](https://img.shields.io/badge/License-GPLv2-orange.svg)]()
[![WCAG](https://img.shields.io/badge/WCAG-2.1%20AA%2FAAA-brightgreen.svg)]()

> **Plugin Màu Sắc Website (Color & Theme Customizer Pro)** là giải pháp toàn diện cho phép thay đổi nhận diện màu sắc của toàn bộ website theo thời gian thực. Tích hợp **12+ bộ màu UI/UX cao cấp**, **Dashboard quản trị hiện đại**, **hỗ trợ Chế độ Sáng/Tối (Dark/Light Mode)**, **kiểm tra độ tương phản chuẩn WCAG 2.1** và **Widget đổi màu nổi cho khách truy cập**.

---

## 🌟 Tính Năng Nổi Bật

- 🎛️ **Dashboard Quản Trị Chuyên Nghiệp**: Giao diện tab hiện đại, xem trước trực quan (Live Preview) ngay lập tức trên website mẫu khi kéo chọn màu.
- 🎨 **12+ Bộ Màu Mẫu Cao Cấp**: Phối sẵn theo chuẩn thiết kế hiện đại (Xanh Công Nghệ, Ngọc Lục Bảo, Cyberpunk Dark, Hoàng Hôn, Tím Hoàng Gia, Gió Biển, Kẹo Ngọt Pastel, Vintage Gold, Forest Zen,...).
- 🧩 **Tùy Chỉnh Phân Lớp Toàn Diện**:
  - Màu thương hiệu (Primary, Secondary, Accent, Hover).
  - Màu nền trang & Khối thẻ nội dung (Background, Surface/Card, Border).
  - Màu chữ & Tiêu đề (Headings, Body text, Muted text).
  - Thanh điều hướng (Header) & Chân trang (Footer).
  - Nút bấm (Button background, Button text, Hover).
- 🌙 **Hỗ Trợ Chế Độ Tối (Dark Mode)**: Chuyển đổi mượt mà 60fps, tương thích chuẩn màn hình OLED & chống mỏi mắt.
- 📊 **Kiểm Tra Độ Tương Phản Chuẩn WCAG 2.1**: Tự động tính toán tỉ lệ tương phản chữ và nền, hiển thị huy hiệu đạt chuẩn AA / AAA.
- 🔘 **Floating Switcher Widget**: Nút tròn nổi ở góc màn hình cho phép khách truy cập tự do đổi màu giao diện hoặc bật/tắt Dark Mode.
- 💾 **Tự Động Lưu Cấu Hình**: Lưu trữ tùy chọn qua `localStorage` và hệ thống `wp_options` của WordPress.
- 📦 **Xuất & Nhập Cấu Hình**: Sao lưu JSON hoặc sao chép mã CSS Variables nhúng nhanh vào bất kỳ website nào.

---

## 📁 Cấu Trúc Thư Mục Dự Án

```
plugin-mausac/
├── plugin-mausac.php            # File khởi chạy chính WordPress Plugin
├── readme.txt                    # Tài liệu chuẩn WordPress Plugin Repository
├── README.md                     # Tài liệu GitHub Repository
├── index.html                    # Trang Demo Live Tương tác Trực quan
│
├── includes/                     # Logic xử lý PHP
│   ├── class-mausac-admin.php    # Quản lý Menu, Settings API, AJAX Security
│   └── class-mausac-frontend.php # Tự động Inject CSS Variables & Widget vào Frontend
│
├── admin/                        # Giao diện & Script Quản trị
│   ├── views/
│   │   └── dashboard.php         # Template giao diện Dashboard chia tab
│   ├── css/
│   │   └── admin-style.css       # CSS Dashboard hiện đại, Live Preview styling
│   └── js/
│       └── admin-script.js       # Xử lý tương tác, 12 presets, WCAG analyzer, Export/Import
│
├── public/                       # Assets phía Frontend (Người dùng cuối)
│   ├── css/
│   │   └── frontend-style.css    # CSS Variables toàn cục, hiệu ứng chuyển màu mượt mà
│   └── js/
│       └── frontend-script.js    # Logic Widget nổi, lưu LocalStorage, Dark Mode
│
└── standalone/                   # Thư viện nhúng độc lập (Dành cho mọi website)
    ├── mausac-plugin.js          # File JS gộp độc lập
    └── mausac-plugin.css         # File CSS gộp độc lập
```

---

## 🚀 Hướng Dẫn Cài Đặt

### 1. Dành cho WordPress
1. Tải file `plugin-mausac.zip` từ mục [Releases](https://github.com/) hoặc nén thư mục `plugin-mausac`.
2. Truy cập trang quản trị WordPress -> **Gói mở rộng (Plugins)** -> **Thêm mới (Add New)** -> **Tải gói mở rộng lên (Upload Plugin)**.
3. Chọn file `plugin-mausac.zip` và bấm **Cài đặt ngay (Install Now)**.
4. Bấm **Kích hoạt (Activate Plugin)**.
5. Truy cập menu **Màu Sắc Web** trên thanh điều hướng bên trái để bắt đầu cấu hình.

### 2. Dành cho Website HTML / PHP / React / Vue / Laravel (Standalone)
Nhúng 2 file trong thư mục `standalone/` vào trang web của bạn:

```html
<!-- Thêm CSS vào thẻ <head> -->
<link rel="stylesheet" href="standalone/mausac-plugin.css">

<!-- Thêm JS trước thẻ đóng </body> -->
<script src="standalone/mausac-plugin.js"></script>
<script>
  // Khởi tạo plugin với các tùy chọn
  MauSacPlugin.init({
    widget: true,                // Bật widget nổi
    position: 'bottom-right',    // 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left'
    defaultTheme: 'modern-blue', // Theme mặc định
    enableDarkMode: true         // Cho phép Dark Mode
  });
</script>
```

### 3. Trải nghiệm Demo trực tiếp
Mở file `index.html` trực tiếp trên bất kỳ trình duyệt nào để trải nghiệm đầy đủ giao diện Dashboard, thử nghiệm 12 bộ màu mẫu và kiểm tra tương tác Live Preview.

---

## 🎨 Hệ Thống Biến CSS Variables

Plugin cung cấp hệ thống biến CSS chuẩn giúp bạn dễ dàng áp dụng lên toàn bộ giao diện:

| Biến CSS | Mô tả |
| :--- | :--- |
| `--ms-primary` | Màu nhận diện thương hiệu chính |
| `--ms-primary-hover` | Màu chính khi di chuột (Hover) |
| `--ms-secondary` | Màu phụ / Điểm nhấn bổ trợ |
| `--ms-accent` | Màu huy hiệu / Nổi bật |
| `--ms-bg` | Màu nền toàn bộ website |
| `--ms-surface` | Màu nền thẻ khối (Card / Container) |
| `--ms-surface-border` | Màu đường viền / Phân cách |
| `--ms-text-primary` | Màu chữ chính / Tiêu đề |
| `--ms-text-secondary` | Màu chữ phụ / Mô tả |
| `--ms-header-bg` | Màu nền thanh điều hướng Header |
| `--ms-header-text` | Màu chữ & Menu Header |
| `--ms-footer-bg` | Màu nền chân trang Footer |
| `--ms-footer-text` | Màu chữ chân trang Footer |
| `--ms-btn-bg` | Màu nền nút bấm |
| `--ms-btn-text` | Màu chữ trên nút bấm |

---

## 📄 Bản Quyền & Giấy Phép

Phát hành dưới giấy phép [GNU General Public License v2.0](LICENSE). Tự do sử dụng, chỉnh sửa và phân phối cho mục đích cá nhân cũng như thương mại.
