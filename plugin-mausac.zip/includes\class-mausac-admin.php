<?php
/**
 * Handles WordPress Admin Menu, Settings API, AJAX handlers, and Dashboard rendering.
 *
 * @package PluginMauSac
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class MauSac_Admin {

    private static $instance = null;
    private $page_hook = '';

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'register_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // AJAX handlers
        add_action('wp_ajax_mausac_save_settings', array($this, 'ajax_save_settings'));
        add_action('wp_ajax_mausac_reset_settings', array($this, 'ajax_reset_settings'));
    }

    /**
     * Register Admin Menu item
     */
    public function register_admin_menu() {
        $this->page_hook = add_menu_page(
            __('Tùy Chỉnh Màu Sắc Website', 'plugin-mausac'),
            __('Màu Sắc Web', 'plugin-mausac'),
            'manage_options',
            'plugin-mausac',
            array($this, 'render_dashboard_page'),
            'dashicons-art',
            65
        );
    }

    /**
     * Enqueue Admin Assets only on our plugin settings page
     */
    public function enqueue_admin_assets($hook) {
        if ($hook !== $this->page_hook) {
            return;
        }

        // Color Picker dependencies
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        // Plugin Admin Styles & Scripts
        wp_enqueue_style(
            'mausac-admin-style',
            MAUSAC_PLUGIN_URL . 'admin/css/admin-style.css',
            array(),
            MAUSAC_VERSION
        );

        wp_enqueue_script(
            'mausac-admin-script',
            MAUSAC_PLUGIN_URL . 'admin/js/admin-script.js',
            array('jquery', 'wp-color-picker'),
            MAUSAC_VERSION,
            true
        );

        $options = get_option('mausac_customizer_options', array());

        wp_localize_script('mausac-admin-script', 'MausacAdminData', array(
            'ajaxUrl'  => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('mausac_admin_nonce'),
            'siteUrl'  => home_url('/'),
            'options'  => $options,
            'strings'  => array(
                'saving'      => __('Đang lưu cấu hình...', 'plugin-mausac'),
                'saved'       => __('Đã lưu cài đặt thành công!', 'plugin-mausac'),
                'resetting'   => __('Đang khôi phục...', 'plugin-mausac'),
                'resetDone'   => __('Đã khôi phục cài đặt gốc!', 'plugin-mausac'),
                'error'       => __('Có lỗi xảy ra, vui lòng thử lại.', 'plugin-mausac'),
                'confirmReset'=> __('Bạn có chắc chắn muốn khôi phục về cài đặt gốc?', 'plugin-mausac')
            )
        ));
    }

    /**
     * AJAX Handler: Save Settings
     */
    public function ajax_save_settings() {
        check_ajax_referer('mausac_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Bạn không có quyền thực hiện thao tác này.', 'plugin-mausac')));
        }

        $raw_data = isset($_POST['settings']) ? wp_unslash($_POST['settings']) : '';
        if (empty($raw_data)) {
            wp_send_json_error(array('message' => __('Dữ liệu không hợp lệ.', 'plugin-mausac')));
        }

        $settings = json_decode($raw_data, true);
        if (!is_array($settings)) {
            wp_send_json_error(array('message' => __('Dữ liệu JSON không hợp lệ.', 'plugin-mausac')));
        }

        // Sanitize
        $clean_options = array(
            'enabled'                => isset($settings['enabled']) ? (bool)$settings['enabled'] : true,
            'active_preset'          => sanitize_text_field(isset($settings['active_preset']) ? $settings['active_preset'] : 'modern-blue'),
            'widget_enabled'         => isset($settings['widget_enabled']) ? (bool)$settings['widget_enabled'] : true,
            'widget_position'        => sanitize_text_field(isset($settings['widget_position']) ? $settings['widget_position'] : 'bottom-right'),
            'enable_dark_mode'       => isset($settings['enable_dark_mode']) ? (bool)$settings['enable_dark_mode'] : true,
            'allow_visitor_override' => isset($settings['allow_visitor_override']) ? (bool)$settings['allow_visitor_override'] : true,
            'colors'                 => array(),
            'dark_colors'            => array(),
            'custom_css'             => isset($settings['custom_css']) ? sanitize_textarea_field($settings['custom_css']) : '',
            'updated_at'             => current_time('mysql')
        );

        if (isset($settings['colors']) && is_array($settings['colors'])) {
            foreach ($settings['colors'] as $key => $val) {
                $clean_options['colors'][sanitize_text_field($key)] = sanitize_hex_color($val) ? sanitize_hex_color($val) : sanitize_text_field($val);
            }
        }

        if (isset($settings['dark_colors']) && is_array($settings['dark_colors'])) {
            foreach ($settings['dark_colors'] as $key => $val) {
                $clean_options['dark_colors'][sanitize_text_field($key)] = sanitize_hex_color($val) ? sanitize_hex_color($val) : sanitize_text_field($val);
            }
        }

        update_option('mausac_customizer_options', $clean_options);

        wp_send_json_success(array(
            'message'  => __('Đã lưu cấu hình màu sắc thành công!', 'plugin-mausac'),
            'settings' => $clean_options
        ));
    }

    /**
     * AJAX Handler: Reset Settings
     */
    public function ajax_reset_settings() {
        check_ajax_referer('mausac_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Bạn không có quyền thực hiện thao tác này.', 'plugin-mausac')));
        }

        delete_option('mausac_customizer_options');

        wp_send_json_success(array(
            'message' => __('Đã khôi phục toàn bộ cài đặt về mặc định.', 'plugin-mausac')
        ));
    }

    /**
     * Render Dashboard Page
     */
    public function render_dashboard_page() {
        $view_path = MAUSAC_PLUGIN_DIR . 'admin/views/dashboard.php';
        if (file_exists($view_path)) {
            require_once $view_path;
        } else {
            echo '<div class="wrap"><h1>Plugin MauSac: View file missing</h1></div>';
        }
    }
}
