<?php
/**
 * Admin Dashboard View for Plugin MauSac
 *
 * @package PluginMauSac
 */

if (!defined('ABSPATH')) {
    // If accessed standalone, define a mock or return
    if (!defined('MAUSAC_VERSION')) {
        define('MAUSAC_VERSION', '1.0.0');
    }
}

$options = get_option('mausac_customizer_options', array());
$is_enabled = isset($options['enabled']) ? $options['enabled'] : true;
$active_preset = isset($options['active_preset']) ? $options['active_preset'] : 'modern-blue';
$widget_enabled = isset($options['widget_enabled']) ? $options['widget_enabled'] : true;
$widget_position = isset($options['widget_position']) ? $options['widget_position'] : 'bottom-right';
$enable_dark_mode = isset($options['enable_dark_mode']) ? $options['enable_dark_mode'] : true;
$custom_css = isset($options['custom_css']) ? $options['custom_css'] : '';
?>

<div class="mausac-dashboard-wrap">
  <!-- Top Navigation Header -->
  <header class="ms-dash-header">
    <div class="ms-header-left">
      <div class="ms-brand-badge">
        <svg class="ms-logo-icon" viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L4.35 19.4c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l1.9-1.9C9.28 19.57 10.59 20 12 20c4.97 0 9-4.03 9-9s-4.03-9-9-9zm0 15c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/><circle cx="8" cy="11" r="1.5"/><circle cx="12" cy="8" r="1.5"/><circle cx="16" cy="11" r="1.5"/><circle cx="14" cy="15" r="1.5"/><circle cx="10" cy="15" r="1.5"/></svg>
        <div>
          <h1 class="ms-dash-title">Bộ Tùy Chỉnh Màu Sắc Website</h1>
          <p class="ms-dash-subtitle">Website Color & Theme Management Pro</p>
        </div>
      </div>
      <div class="ms-status-pill ms-status-active">
        <span class="ms-pulse-dot"></span>
        <span id="ms-status-text">Đang Hoạt Động</span>
      </div>
    </div>

    <div class="ms-header-actions">
      <button type="button" id="ms-btn-admin-reset" class="ms-btn ms-btn-outline" title="Khôi phục cài đặt mặc định">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
        <span>Khôi phục gốc</span>
      </button>
      <button type="button" id="ms-btn-admin-save" class="ms-btn ms-btn-primary">
        <svg class="ms-btn-spinner" width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" stroke-dasharray="32" stroke-linecap="round"/></svg>
        <svg class="ms-btn-save-icon" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm2 16H5V5h11.17L19 7.83V19zm-7-7c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3zM6 6h9v4H6z"/></svg>
        <span>Lưu Cấu Hình</span>
      </button>
    </div>
  </header>

  <!-- Main Container Split -->
  <div class="ms-dash-body">
    <!-- Left Navigation Tabs & Settings -->
    <div class="ms-dash-sidebar">
      <nav class="ms-nav-tabs">
        <button class="ms-nav-item active" data-tab="tab-presets">
          <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 0 0 0 18c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>
          <span>Bộ Màu Mẫu (Presets)</span>
          <span class="ms-tab-count">12</span>
        </button>

        <button class="ms-nav-item" data-tab="tab-colors">
          <svg viewBox="0 0 24 24"><path d="M12 22C6.49 22 2 17.51 2 12S6.49 2 12 2s10 4.04 10 9c0 3.31-2.69 6-6 6h-1.77c-.28 0-.5.22-.5.5 0 .12.05.23.13.33.41.47.64 1.06.64 1.67A2.5 2.5 0 0 1 12 22zm0-18c-4.41 0-8 3.59-8 8s3.59 8 8 8c.28 0 .5-.22.5-.5 0-.16-.08-.28-.14-.35-.41-.46-.63-1.05-.63-1.65a2.5 2.5 0 0 1 2.5-2.5H16c2.21 0 4-1.79 4-4 0-3.86-3.59-7-8-7z"/></svg>
          <span>Tùy Chỉnh Chi Tiết</span>
        </button>

        <button class="ms-nav-item" data-tab="tab-darkmode">
          <svg viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-.46-.04-.92-.1-1.36-.98 1.37-2.58 2.26-4.4 2.26-2.98 0-5.4-2.42-5.4-5.4 0-1.81.89-3.42 2.26-4.4-.44-.06-.9-.1-1.36-.1z"/></svg>
          <span>Chế Độ Sáng / Tối</span>
        </button>

        <button class="ms-nav-item" data-tab="tab-widget">
          <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z"/><circle cx="16" cy="16" r="2"/><path d="M7 7h10v2H7zm0 4h7v2H7z"/></svg>
          <span>Widget Nổi Khách Hàng</span>
        </button>

        <button class="ms-nav-item" data-tab="tab-wcag">
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
          <span>Độ Tương Phản (WCAG)</span>
        </button>

        <button class="ms-nav-item" data-tab="tab-export">
          <svg viewBox="0 0 24 24"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/></svg>
          <span>Xuất / Nhập & Mã CSS</span>
        </button>
      </nav>

      <!-- Tab Content Area -->
      <div class="ms-tab-content-container">
        
        <!-- 1. TAB PRESETS -->
        <div class="ms-tab-panel active" id="tab-presets">
          <div class="ms-panel-intro">
            <h3>Bộ Màu Thiết Kế Sẵn Chuẩn UI/UX</h3>
            <p>Chọn một bảng màu dưới đây để áp dụng ngay lập tức cho toàn bộ giao diện trang web của bạn.</p>
          </div>

          <div class="ms-presets-admin-grid" id="ms-admin-presets-list">
            <!-- Rendered by JS -->
          </div>
        </div>

        <!-- 2. TAB CUSTOM COLORS -->
        <div class="ms-tab-panel" id="tab-colors">
          <div class="ms-panel-intro">
            <h3>Tùy Chỉnh Từng Mã Màu Cụ Thể</h3>
            <p>Điều chỉnh màu sắc của từng thành phần để phù hợp chính xác với bộ nhận diện thương hiệu.</p>
          </div>

          <!-- Section: Brand Colors -->
          <div class="ms-color-group">
            <h4 class="ms-group-title">
              <span class="ms-group-icon">🎯</span>
              Màu Thương Hiệu & Điểm Nhấn
            </h4>
            <div class="ms-color-grid">
              <div class="ms-color-item">
                <label>Màu Chính (Primary)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-primary" value="#2563eb">
                  <input type="text" class="ms-hex-text" data-var="--ms-primary" value="#2563eb" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Màu Chính Hover</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-primary-hover" value="#1d4ed8">
                  <input type="text" class="ms-hex-text" data-var="--ms-primary-hover" value="#1d4ed8" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Màu Phụ (Secondary)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-secondary" value="#06b6d4">
                  <input type="text" class="ms-hex-text" data-var="--ms-secondary" value="#06b6d4" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Màu Điểm Nhấn (Accent)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-accent" value="#f59e0b">
                  <input type="text" class="ms-hex-text" data-var="--ms-accent" value="#f59e0b" spellcheck="false">
                </div>
              </div>
            </div>
          </div>

          <!-- Section: Background & Cards -->
          <div class="ms-color-group">
            <h4 class="ms-group-title">
              <span class="ms-group-icon">🖼️</span>
              Nền Trang & Khối Nội Dung (Cards)
            </h4>
            <div class="ms-color-grid">
              <div class="ms-color-item">
                <label>Nền Toàn Trang (Background)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-bg" value="#f8fafc">
                  <input type="text" class="ms-hex-text" data-var="--ms-bg" value="#f8fafc" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Nền Thẻ / Khối (Surface / Card)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-surface" value="#ffffff">
                  <input type="text" class="ms-hex-text" data-var="--ms-surface" value="#ffffff" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Màu Đường Viền (Border / Divider)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-surface-border" value="#e2e8f0">
                  <input type="text" class="ms-hex-text" data-var="--ms-surface-border" value="#e2e8f0" spellcheck="false">
                </div>
              </div>
            </div>
          </div>

          <!-- Section: Typography -->
          <div class="ms-color-group">
            <h4 class="ms-group-title">
              <span class="ms-group-icon">✍️</span>
              Màu Chữ & Nội Dung
            </h4>
            <div class="ms-color-grid">
              <div class="ms-color-item">
                <label>Chữ Chính / Tiêu Đề</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-text-primary" value="#0f172a">
                  <input type="text" class="ms-hex-text" data-var="--ms-text-primary" value="#0f172a" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Chữ Phụ / Mô Tả (Muted)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-text-secondary" value="#64748b">
                  <input type="text" class="ms-hex-text" data-var="--ms-text-secondary" value="#64748b" spellcheck="false">
                </div>
              </div>
            </div>
          </div>

          <!-- Section: Header & Footer -->
          <div class="ms-color-group">
            <h4 class="ms-group-title">
              <span class="ms-group-icon">🧭</span>
              Thanh Điều Hướng (Header) & Chân Trang (Footer)
            </h4>
            <div class="ms-color-grid">
              <div class="ms-color-item">
                <label>Nền Header</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-header-bg" value="#ffffff">
                  <input type="text" class="ms-hex-text" data-var="--ms-header-bg" value="#ffffff" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Chữ & Menu Header</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-header-text" value="#0f172a">
                  <input type="text" class="ms-hex-text" data-var="--ms-header-text" value="#0f172a" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Nền Footer</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-footer-bg" value="#0f172a">
                  <input type="text" class="ms-hex-text" data-var="--ms-footer-bg" value="#0f172a" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Chữ Footer</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-footer-text" value="#f8fafc">
                  <input type="text" class="ms-hex-text" data-var="--ms-footer-text" value="#f8fafc" spellcheck="false">
                </div>
              </div>
            </div>
          </div>

          <!-- Section: Buttons -->
          <div class="ms-color-group">
            <h4 class="ms-group-title">
              <span class="ms-group-icon">🔘</span>
              Nút Bấm (Buttons)
            </h4>
            <div class="ms-color-grid">
              <div class="ms-color-item">
                <label>Nền Nút Bấm Chính</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-btn-bg" value="#2563eb">
                  <input type="text" class="ms-hex-text" data-var="--ms-btn-bg" value="#2563eb" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Chữ Nút Bấm</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-btn-text" value="#ffffff">
                  <input type="text" class="ms-hex-text" data-var="--ms-btn-text" value="#ffffff" spellcheck="false">
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- 3. TAB DARK MODE -->
        <div class="ms-tab-panel" id="tab-darkmode">
          <div class="ms-panel-intro">
            <h3>Cài Đặt Chế Độ Tối (Dark Mode)</h3>
            <p>Quản lý hành vi và bảng màu khi người dùng kích hoạt giao diện ban đêm.</p>
          </div>

          <div class="ms-card-setting">
            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Kích hoạt Chế độ Tối</h4>
                <p>Cho phép website hỗ trợ hiển thị giao diện Dark Mode tương thích chuẩn OLED & bảo vệ mắt.</p>
              </div>
              <label class="ms-toggle-switch">
                <input type="checkbox" id="ms-setting-enable-dark" checked>
                <span class="ms-toggle-slider"></span>
              </label>
            </div>

            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Xem trước Dark Mode ngay bây giờ</h4>
                <p>Bật để kiểm tra các thành phần hiển thị trên nền tối trong khung Live Preview.</p>
              </div>
              <button type="button" id="ms-btn-preview-dark" class="ms-btn ms-btn-outline">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-.46-.04-.92-.1-1.36-.98 1.37-2.58 2.26-4.4 2.26-2.98 0-5.4-2.42-5.4-5.4 0-1.81.89-3.42 2.26-4.4-.44-.06-.9-.1-1.36-.1z"/></svg>
                <span id="ms-preview-dark-text">Bật Xem Trước Dark Mode</span>
              </button>
            </div>
          </div>

          <div class="ms-color-group">
            <h4 class="ms-group-title">
              <span class="ms-group-icon">🌙</span>
              Màu Sắc Dành Riêng Cho Dark Mode
            </h4>
            <div class="ms-color-grid">
              <div class="ms-color-item">
                <label>Nền Trang Tối (Dark BG)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-dark-bg" value="#090d16">
                  <input type="text" class="ms-hex-text" data-var="--ms-dark-bg" value="#090d16" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Nền Thẻ Tối (Dark Surface)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-dark-surface" value="#111827">
                  <input type="text" class="ms-hex-text" data-var="--ms-dark-surface" value="#111827" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Chữ Chính Tối (Dark Text)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-dark-text" value="#f3f4f6">
                  <input type="text" class="ms-hex-text" data-var="--ms-dark-text" value="#f3f4f6" spellcheck="false">
                </div>
              </div>
              <div class="ms-color-item">
                <label>Chữ Phụ Tối (Dark Muted Text)</label>
                <div class="ms-picker-wrap">
                  <input type="color" class="ms-color-input" data-var="--ms-dark-text-muted" value="#9ca3af">
                  <input type="text" class="ms-hex-text" data-var="--ms-dark-text-muted" value="#9ca3af" spellcheck="false">
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 4. TAB FLOATING WIDGET -->
        <div class="ms-tab-panel" id="tab-widget">
          <div class="ms-panel-intro">
            <h3>Cài Đặt Widget Nổi Khách Hàng (Floating Switcher)</h3>
            <p>Hiển thị một nút tròn nổi ở góc màn hình để khách truy cập có thể tự chọn màu giao diện ưa thích.</p>
          </div>

          <div class="ms-card-setting">
            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Hiển thị Widget Đổi Màu Trên Website</h4>
                <p>Khách xem trang có thể bấm vào widget để đổi bộ màu hoặc chuyển đổi Dark Mode.</p>
              </div>
              <label class="ms-toggle-switch">
                <input type="checkbox" id="ms-setting-widget-enabled" checked>
                <span class="ms-toggle-slider"></span>
              </label>
            </div>

            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Vị trí hiển thị Widget</h4>
                <p>Chọn góc màn hình phù hợp với bố cục website của bạn.</p>
              </div>
              <select id="ms-setting-widget-pos" class="ms-select-input">
                <option value="bottom-right" selected>Góc dưới cùng Bên Phải (Khuyên dùng)</option>
                <option value="bottom-left">Góc dưới cùng Bên Trái</option>
                <option value="top-right">Góc trên cùng Bên Phải</option>
                <option value="top-left">Góc trên cùng Bên Trái</option>
              </select>
            </div>

            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Lưu lựa chọn của Khách (LocalStorage)</h4>
                <p>Tự động ghi nhớ màu mà khách đã chọn khi họ tải lại trang hoặc mở trang mới.</p>
              </div>
              <label class="ms-toggle-switch">
                <input type="checkbox" id="ms-setting-save-local" checked>
                <span class="ms-toggle-slider"></span>
              </label>
            </div>
          </div>
        </div>

        <!-- 5. TAB WCAG ACCESSIBILITY CHECKER -->
        <div class="ms-tab-panel" id="tab-wcag">
          <div class="ms-panel-intro">
            <h3>Kiểm Tra Độ Tương Phản Chuẩn WCAG 2.1</h3>
            <p>Đảm bảo văn bản trên website của bạn luôn dễ đọc và đáp ứng tiêu chuẩn tiếp cận người dùng toàn cầu.</p>
          </div>

          <div class="ms-wcag-audit-card">
            <div class="ms-wcag-score-box">
              <div class="ms-wcag-score-circle" id="ms-wcag-ratio">4.8:1</div>
              <div class="ms-wcag-score-details">
                <h4 id="ms-wcag-verdict">Đạt Chuẩn AA (Tốt)</h4>
                <p>Tỉ lệ tương phản giữa màu chữ chính và nền trang hiện tại.</p>
              </div>
            </div>

            <div class="ms-wcag-grid">
              <div class="ms-wcag-item" id="wcag-body-status">
                <div class="ms-wcag-item-title">Chữ Chính trên Nền Trang</div>
                <div class="ms-wcag-pill pass">AA Passed</div>
              </div>
              <div class="ms-wcag-item" id="wcag-btn-status">
                <div class="ms-wcag-item-title">Chữ Nút trên Nền Nút Bấm</div>
                <div class="ms-wcag-pill pass">AAA Passed</div>
              </div>
              <div class="ms-wcag-item" id="wcag-header-status">
                <div class="ms-wcag-item-title">Menu trên Nền Header</div>
                <div class="ms-wcag-pill pass">AA Passed</div>
              </div>
              <div class="ms-wcag-item" id="wcag-footer-status">
                <div class="ms-wcag-item-title">Chữ trên Nền Footer</div>
                <div class="ms-wcag-pill pass">AAA Passed</div>
              </div>
            </div>
          </div>
        </div>

        <!-- 6. TAB EXPORT / IMPORT / CSS -->
        <div class="ms-tab-panel" id="tab-export">
          <div class="ms-panel-intro">
            <h3>Xuất Mã CSS & Sao Lưu Cấu Hình</h3>
            <p>Sao chép mã CSS để nhúng vào bất kỳ trang web nào hoặc sao lưu/khôi phục dữ liệu cấu hình.</p>
          </div>

          <div class="ms-code-card">
            <div class="ms-code-header">
              <span>Mã CSS Variables Được Tạo Tự Động</span>
              <button type="button" id="ms-btn-copy-css" class="ms-btn ms-btn-sm ms-btn-outline">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
                Sao chép CSS
              </button>
            </div>
            <pre class="ms-code-block"><code id="ms-generated-css">/* Mã CSS sẽ xuất hiện ở đây */</code></pre>
          </div>

          <div class="ms-card-setting" style="margin-top: 20px;">
            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Xuất File Sao Lưu (Export JSON)</h4>
                <p>Tải xuống file cấu hình định dạng .json để lưu trữ hoặc chuyển sang website khác.</p>
              </div>
              <button type="button" id="ms-btn-export-json" class="ms-btn ms-btn-outline">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                Tải JSON
              </button>
            </div>

            <div class="ms-setting-row">
              <div class="ms-setting-info">
                <h4>Nhập File Sao Lưu (Import JSON)</h4>
                <p>Tải lên file cấu hình JSON đã lưu trước đó để khôi phục nhanh.</p>
              </div>
              <div>
                <input type="file" id="ms-import-file" accept=".json" style="display:none;">
                <button type="button" id="ms-btn-trigger-import" class="ms-btn ms-btn-outline">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/></svg>
                  Chọn File JSON
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

    <!-- Right Live Preview Showcase Container -->
    <div class="ms-dash-preview-wrap">
      <div class="ms-preview-toolbar">
        <div class="ms-preview-title">
          <span class="ms-live-badge">LIVE PREVIEW</span>
          <span>Xem Trước Giao Diện Thực Tế</span>
        </div>

        <div class="ms-device-switcher">
          <button class="ms-device-btn active" data-device="desktop" title="Màn hình máy tính">
            <svg viewBox="0 0 24 24"><path d="M21 2H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h7l-2 3v1h8v-1l-2-3h7c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 12H3V4h18v10z"/></svg>
          </button>
          <button class="ms-device-btn" data-device="tablet" title="Máy tính bảng">
            <svg viewBox="0 0 24 24"><path d="M18.5 0h-13C4.12 0 3 1.12 3 2.5v19C3 22.88 4.12 24 5.5 24h13c1.38 0 2.5-1.12 2.5-2.5v-19C21 1.12 19.88 0 18.5 0zm-6 22c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm6.5-4H5V3h14v15z"/></svg>
          </button>
          <button class="ms-device-btn" data-device="mobile" title="Điện thoại">
            <svg viewBox="0 0 24 24"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"/></svg>
          </button>
        </div>
      </div>

      <!-- Preview Screen Frame with Realistic Website Structure -->
      <div class="ms-preview-stage" id="ms-preview-stage">
        <div class="ms-mock-website" id="ms-mock-site">
          
          <!-- Mock Header / Navbar -->
          <header class="ms-mock-header">
            <div class="ms-mock-logo">
              <span class="ms-mock-logo-icon">✨</span>
              <span>TechNova Solutions</span>
            </div>
            <nav class="ms-mock-nav">
              <a href="javascript:void(0)" class="ms-active">Trang Chủ</a>
              <a href="javascript:void(0)">Dịch Vụ</a>
              <a href="javascript:void(0)">Tính Năng</a>
              <a href="javascript:void(0)">Bảng Giá</a>
              <a href="javascript:void(0)">Liên Hệ</a>
            </nav>
            <div class="ms-mock-header-action">
              <button class="ms-mock-btn-sm">Dùng Thử Miễn Phí</button>
            </div>
          </header>

          <!-- Mock Hero Section -->
          <section class="ms-mock-hero">
            <div class="ms-mock-hero-content">
              <span class="ms-mock-badge">🚀 Đột phá công nghệ 2026</span>
              <h1 class="ms-mock-hero-title">Nâng Tầm Trải Nghiệm Màu Sắc Cho Website Của Bạn</h1>
              <p class="ms-mock-hero-desc">
                Hệ thống tùy biến màu sắc thông minh theo chuẩn thiết kế hiện đại. Thay đổi bảng màu toàn diện chỉ với một thao tác, tương thích 100% mọi giao diện và tối ưu trải nghiệm người dùng.
              </p>
              <div class="ms-mock-hero-btns">
                <button class="ms-mock-btn-main">Bắt Đầu Ngay Hôm Nay</button>
                <button class="ms-mock-btn-ghost">Xem Video Giới Thiệu</button>
              </div>
            </div>
            <div class="ms-mock-hero-visual">
              <div class="ms-mock-hero-card">
                <div class="ms-hero-card-header">
                  <div class="ms-card-dots"><span></span><span></span><span></span></div>
                  <span class="ms-card-stat">+148% Tương tác</span>
                </div>
                <div class="ms-hero-card-body">
                  <div class="ms-mock-bar" style="width: 85%;"></div>
                  <div class="ms-mock-bar" style="width: 65%;"></div>
                  <div class="ms-mock-bar" style="width: 90%;"></div>
                </div>
              </div>
            </div>
          </section>

          <!-- Mock Features Cards -->
          <section class="ms-mock-features">
            <div class="ms-mock-section-heading">
              <h2>Tính Năng Vượt Trội</h2>
              <p>Mọi công cụ bạn cần để xây dựng một website có màu sắc ấn tượng và chuyên nghiệp.</p>
            </div>
            <div class="ms-mock-cards-grid">
              <div class="ms-mock-card">
                <div class="ms-mock-card-icon">⚡</div>
                <h3>Tốc Độ Tải Siêu Tốc</h3>
                <p>Tối ưu CSS Variables cực nhẹ, chuyển màu mượt mà 60fps không gây giật lag trang.</p>
                <a href="javascript:void(0)" class="ms-mock-link">Tìm hiểu thêm →</a>
              </div>
              <div class="ms-mock-card ms-mock-card-highlight">
                <div class="ms-mock-card-icon">🎨</div>
                <h3>12+ Bộ Màu Cao Cấp</h3>
                <p>Phối màu bởi các chuyên gia UI/UX hàng đầu, sẵn sàng áp dụng chỉ với 1 cú nhấp chuột.</p>
                <a href="javascript:void(0)" class="ms-mock-link">Tìm hiểu thêm →</a>
              </div>
              <div class="ms-mock-card">
                <div class="ms-mock-card-icon">🛡️</div>
                <h3>Chuẩn Tiếp Cận WCAG</h3>
                <p>Tự động kiểm tra độ tương phản đảm bảo mọi khách hàng đều đọc nội dung rõ nét nhất.</p>
                <a href="javascript:void(0)" class="ms-mock-link">Tìm hiểu thêm →</a>
              </div>
            </div>
          </section>

          <!-- Mock Pricing Section -->
          <section class="ms-mock-pricing">
            <div class="ms-mock-section-heading">
              <h2>Bảng Giá Linh Hoạt</h2>
              <p>Chọn gói phù hợp với quy mô doanh nghiệp của bạn.</p>
            </div>
            <div class="ms-mock-pricing-grid">
              <div class="ms-mock-pricing-card">
                <h4>Gói Cơ Bản</h4>
                <div class="ms-mock-price">0đ <span>/tháng</span></div>
                <ul class="ms-mock-price-list">
                  <li>✓ 5 Bộ màu cơ bản</li>
                  <li>✓ Tùy chỉnh CSS nhẹ</li>
                  <li>✓ Hỗ trợ cộng đồng</li>
                </ul>
                <button class="ms-mock-btn-outline">Chọn Gói Này</button>
              </div>
              <div class="ms-mock-pricing-card ms-pricing-featured">
                <span class="ms-pricing-popular">PHỔ BIẾN NHẤT</span>
                <h4>Gói Chuyên Nghiệp</h4>
                <div class="ms-mock-price">299.000đ <span>/tháng</span></div>
                <ul class="ms-mock-price-list">
                  <li>✓ Toàn bộ 12+ Bộ màu UI/UX</li>
                  <li>✓ Widget nổi cho khách xem</li>
                  <li>✓ Kiểm tra chuẩn WCAG</li>
                  <li>✓ Hỗ trợ kỹ thuật 24/7</li>
                </ul>
                <button class="ms-mock-btn-main">Nâng Cấp Ngay</button>
              </div>
            </div>
          </section>

          <!-- Mock Footer -->
          <footer class="ms-mock-footer">
            <div class="ms-mock-footer-cols">
              <div class="ms-mock-fcol">
                <div class="ms-mock-logo">
                  <span>✨ TechNova Solutions</span>
                </div>
                <p>Giải pháp tùy biến màu sắc thông minh hàng đầu cho website doanh nghiệp.</p>
              </div>
              <div class="ms-mock-fcol">
                <h5>Liên Kết Nhanh</h5>
                <ul>
                  <li><a href="javascript:void(0)">Giới thiệu</a></li>
                  <li><a href="javascript:void(0)">Dịch vụ</a></li>
                  <li><a href="javascript:void(0)">Chính sách</a></li>
                </ul>
              </div>
              <div class="ms-mock-fcol">
                <h5>Bản Quyền</h5>
                <p>© 2026 TechNova Solutions. All rights reserved. Powered by Plugin MauSac.</p>
              </div>
            </div>
          </footer>

        </div>
      </div>
    </div>
  </div>

  <!-- Toast Notification Container -->
  <div id="ms-toast" class="ms-toast">
    <svg class="ms-toast-icon" width="20" height="20" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
    <span id="ms-toast-msg">Đã lưu cài đặt thành công!</span>
  </div>
</div>
