/**
 * Plugin MauSac - Admin Dashboard Script
 * Handles real-time color syncing, preset management, WCAG calculation, live preview, export/import.
 */

(function () {
  'use strict';

  // 12+ Curated UI/UX Presets
  var PRESETS_DATA = {
    'modern-blue': {
      name: 'Xanh Công Nghệ (Modern Blue)',
      desc: 'Phù hợp cho SaaS, công nghệ, startup & doanh nghiệp hiện đại',
      preview: ['#2563eb', '#06b6d4', '#ffffff', '#0f172a'],
      colors: {
        '--ms-primary': '#2563eb',
        '--ms-primary-hover': '#1d4ed8',
        '--ms-secondary': '#06b6d4',
        '--ms-accent': '#f59e0b',
        '--ms-bg': '#f8fafc',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e2e8f0',
        '--ms-text-primary': '#0f172a',
        '--ms-text-secondary': '#64748b',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#0f172a',
        '--ms-footer-bg': '#0f172a',
        '--ms-footer-text': '#f8fafc',
        '--ms-btn-bg': '#2563eb',
        '--ms-btn-text': '#ffffff'
      }
    },
    'emerald-luxury': {
      name: 'Ngọc Lục Bảo (Emerald Luxury)',
      desc: 'Sang trọng, sinh thái, tài chính, spa & sản phẩm thiên nhiên',
      preview: ['#059669', '#10b981', '#ffffff', '#064e3b'],
      colors: {
        '--ms-primary': '#059669',
        '--ms-primary-hover': '#047857',
        '--ms-secondary': '#10b981',
        '--ms-accent': '#10b981',
        '--ms-bg': '#f0fdf4',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#dcfce7',
        '--ms-text-primary': '#064e3b',
        '--ms-text-secondary': '#047857',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#064e3b',
        '--ms-footer-bg': '#022c22',
        '--ms-footer-text': '#f0fdf4',
        '--ms-btn-bg': '#059669',
        '--ms-btn-text': '#ffffff'
      }
    },
    'cyberpunk-dark': {
      name: 'Đêm Tương Lai (Cyberpunk Dark)',
      desc: 'Tone tối huyền ảo, neon bắt mắt dành cho gaming, AI & crypto',
      preview: ['#f43f5e', '#a855f7', '#111827', '#f3f4f6'],
      colors: {
        '--ms-primary': '#f43f5e',
        '--ms-primary-hover': '#e11d48',
        '--ms-secondary': '#a855f7',
        '--ms-accent': '#06b6d4',
        '--ms-bg': '#090d16',
        '--ms-surface': '#111827',
        '--ms-surface-border': '#1f2937',
        '--ms-text-primary': '#f3f4f6',
        '--ms-text-secondary': '#9ca3af',
        '--ms-header-bg': '#0f172a',
        '--ms-header-text': '#f8fafc',
        '--ms-footer-bg': '#030712',
        '--ms-footer-text': '#9ca3af',
        '--ms-btn-bg': '#f43f5e',
        '--ms-btn-text': '#ffffff'
      }
    },
    'sunset-warmth': {
      name: 'Hoàng Hôn Rực Rỡ (Sunset Warmth)',
      desc: 'Ấm áp, sáng tạo, ẩm thực, thời trang & du lịch tràn đầy năng lượng',
      preview: ['#ea580c', '#f59e0b', '#ffffff', '#431407'],
      colors: {
        '--ms-primary': '#ea580c',
        '--ms-primary-hover': '#c2410c',
        '--ms-secondary': '#f59e0b',
        '--ms-accent': '#f59e0b',
        '--ms-bg': '#fffbeb',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fef3c7',
        '--ms-text-primary': '#431407',
        '--ms-text-secondary': '#78350f',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#431407',
        '--ms-footer-bg': '#1c1917',
        '--ms-footer-text': '#fffbeb',
        '--ms-btn-bg': '#ea580c',
        '--ms-btn-text': '#ffffff'
      }
    },
    'royal-purple': {
      name: 'Tím Hoàng Gia (Royal Purple)',
      desc: 'Quý phái, dịch vụ cao cấp, agency sáng tạo & thương mại điện tử',
      preview: ['#7c3aed', '#ec4899', '#ffffff', '#3b0764'],
      colors: {
        '--ms-primary': '#7c3aed',
        '--ms-primary-hover': '#6d28d9',
        '--ms-secondary': '#ec4899',
        '--ms-accent': '#ec4899',
        '--ms-bg': '#faf5ff',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#f3e8ff',
        '--ms-text-primary': '#3b0764',
        '--ms-text-secondary': '#6b21a8',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#3b0764',
        '--ms-footer-bg': '#1e1b4b',
        '--ms-footer-text': '#faf5ff',
        '--ms-btn-bg': '#7c3aed',
        '--ms-btn-text': '#ffffff'
      }
    },
    'ocean-breeze': {
      name: 'Gió Biển Tươi Mát (Ocean Breeze)',
      desc: 'Tươi sáng, năng động, du lịch, y tế, giáo dục & dịch vụ khách hàng',
      preview: ['#0284c7', '#14b8a6', '#ffffff', '#0c4a6e'],
      colors: {
        '--ms-primary': '#0284c7',
        '--ms-primary-hover': '#0369a1',
        '--ms-secondary': '#14b8a6',
        '--ms-accent': '#14b8a6',
        '--ms-bg': '#f0f9ff',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e0f2fe',
        '--ms-text-primary': '#0c4a6e',
        '--ms-text-secondary': '#0369a1',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#0c4a6e',
        '--ms-footer-bg': '#082f49',
        '--ms-footer-text': '#f0f9ff',
        '--ms-btn-bg': '#0284c7',
        '--ms-btn-text': '#ffffff'
      }
    },
    'crimson-passion': {
      name: 'Đỏ Đam Mê (Crimson Passion)',
      desc: 'Mạnh mẽ, kích thích hành động, khuyến mãi, thể thao & ô tô',
      preview: ['#dc2626', '#f97316', '#ffffff', '#450a0a'],
      colors: {
        '--ms-primary': '#dc2626',
        '--ms-primary-hover': '#b91c1c',
        '--ms-secondary': '#f97316',
        '--ms-accent': '#f97316',
        '--ms-bg': '#fef2f2',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fee2e2',
        '--ms-text-primary': '#450a0a',
        '--ms-text-secondary': '#991b1b',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#450a0a',
        '--ms-footer-bg': '#1c1917',
        '--ms-footer-text': '#fef2f2',
        '--ms-btn-bg': '#dc2626',
        '--ms-btn-text': '#ffffff'
      }
    },
    'midnight-obsidian': {
      name: 'Hắc Ngọc Tối (Midnight Obsidian)',
      desc: 'Bí ẩn, sang trọng, tương phản cao, phong cách tối giản',
      preview: ['#6366f1', '#818cf8', '#151c2e', '#f8fafc'],
      colors: {
        '--ms-primary': '#6366f1',
        '--ms-primary-hover': '#4f46e5',
        '--ms-secondary': '#818cf8',
        '--ms-accent': '#818cf8',
        '--ms-bg': '#0b0f19',
        '--ms-surface': '#151c2e',
        '--ms-surface-border': '#1e293b',
        '--ms-text-primary': '#f8fafc',
        '--ms-text-secondary': '#94a3b8',
        '--ms-header-bg': '#0f172a',
        '--ms-header-text': '#f8fafc',
        '--ms-footer-bg': '#020617',
        '--ms-footer-text': '#94a3b8',
        '--ms-btn-bg': '#6366f1',
        '--ms-btn-text': '#ffffff'
      }
    },
    'pastel-dream': {
      name: 'Kẹo Ngọt Mơ Màng (Pastel Dream)',
      desc: 'Nhẹ nhàng, đáng yêu, mỹ phẩm, thời trang nữ & sản phẩm cho bé',
      preview: ['#ec4899', '#8b5cf6', '#ffffff', '#4a044e'],
      colors: {
        '--ms-primary': '#ec4899',
        '--ms-primary-hover': '#db2777',
        '--ms-secondary': '#8b5cf6',
        '--ms-accent': '#ec4899',
        '--ms-bg': '#fdf2f8',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fce7f3',
        '--ms-text-primary': '#4a044e',
        '--ms-text-secondary': '#86198f',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#4a044e',
        '--ms-footer-bg': '#2e1065',
        '--ms-footer-text': '#fdf2f8',
        '--ms-btn-bg': '#ec4899',
        '--ms-btn-text': '#ffffff'
      }
    },
    'vintage-gold': {
      name: 'Hoàng Kim Cổ Điển (Vintage Gold)',
      desc: 'Cổ kính, đẳng cấp, đồng hồ, trang sức & rượu vang cao cấp',
      preview: ['#b45309', '#d97706', '#ffffff', '#451a03'],
      colors: {
        '--ms-primary': '#b45309',
        '--ms-primary-hover': '#92400e',
        '--ms-secondary': '#d97706',
        '--ms-accent': '#d97706',
        '--ms-bg': '#fffbeb',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fef3c7',
        '--ms-text-primary': '#451a03',
        '--ms-text-secondary': '#78350f',
        '--ms-header-bg': '#fef3c7',
        '--ms-header-text': '#451a03',
        '--ms-footer-bg': '#1f1a14',
        '--ms-footer-text': '#fffbeb',
        '--ms-btn-bg': '#b45309',
        '--ms-btn-text': '#ffffff'
      }
    },
    'forest-zen': {
      name: 'Rừng Thiền Tịnh (Forest Zen)',
      desc: 'An yên, mộc mạc, nông sản sạch, trà đạo & lối sống tối giản',
      preview: ['#15803d', '#84cc16', '#ffffff', '#14532d'],
      colors: {
        '--ms-primary': '#15803d',
        '--ms-primary-hover': '#166534',
        '--ms-secondary': '#84cc16',
        '--ms-accent': '#84cc16',
        '--ms-bg': '#f7fee7',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#ecfccb',
        '--ms-text-primary': '#14532d',
        '--ms-text-secondary': '#365314',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#14532d',
        '--ms-footer-bg': '#052e16',
        '--ms-footer-text': '#f7fee7',
        '--ms-btn-bg': '#15803d',
        '--ms-btn-text': '#ffffff'
      }
    },
    'monochrome-minimal': {
      name: 'Tối Giản Đen Trắng (Monochrome)',
      desc: 'Tinh tế, hiện đại, nhiếp ảnh, tạp chí kiến trúc & portfolio nghệ thuật',
      preview: ['#18181b', '#52525b', '#ffffff', '#09090b'],
      colors: {
        '--ms-primary': '#18181b',
        '--ms-primary-hover': '#27272a',
        '--ms-secondary': '#52525b',
        '--ms-accent': '#71717a',
        '--ms-bg': '#fafafa',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e4e4e7',
        '--ms-text-primary': '#09090b',
        '--ms-text-secondary': '#71717a',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#09090b',
        '--ms-footer-bg': '#09090b',
        '--ms-footer-text': '#fafafa',
        '--ms-btn-bg': '#18181b',
        '--ms-btn-text': '#ffffff'
      }
    }
  };

  var MauSacAdmin = {
    currentPreset: 'modern-blue',
    currentColors: {},
    isDarkPreview: false,

    init: function () {
      this.renderPresetsGrid();
      this.bindTabs();
      this.bindColorInputs();
      this.bindDeviceSwitcher();
      this.bindDarkModePreview();
      this.bindExportImport();
      this.bindSaveAndReset();

      // Load initial state
      var initialPreset = 'modern-blue';
      if (window.MausacAdminData && window.MausacAdminData.options && window.MausacAdminData.options.active_preset) {
        initialPreset = window.MausacAdminData.options.active_preset;
      }
      this.applyPreset(initialPreset);
    },

    renderPresetsGrid: function () {
      var container = document.getElementById('ms-admin-presets-list');
      if (!container) return;

      var html = '';
      for (var key in PRESETS_DATA) {
        if (PRESETS_DATA.hasOwnProperty(key)) {
          var p = PRESETS_DATA[key];
          var bars = p.preview.map(function (c) {
            return '<span style="background-color:' + c + '"></span>';
          }).join('');

          html += [
            '<div class="ms-admin-preset-card" data-preset="' + key + '">',
            '  <div class="ms-preset-color-bars">' + bars + '</div>',
            '  <div class="ms-preset-name">' + p.name + '</div>',
            '  <div class="ms-preset-desc">' + p.desc + '</div>',
            '</div>'
          ].join('');
        }
      }
      container.innerHTML = html;

      // Bind click on preset cards
      var self = this;
      container.addEventListener('click', function (e) {
        var card = e.target.closest('.ms-admin-preset-card');
        if (card && card.dataset.preset) {
          self.applyPreset(card.dataset.preset);
        }
      });
    },

    bindTabs: function () {
      var tabBtns = document.querySelectorAll('.ms-nav-item');
      var tabPanels = document.querySelectorAll('.ms-tab-panel');

      tabBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var targetTab = this.dataset.tab;
          tabBtns.forEach(function (b) { b.classList.remove('active'); });
          tabPanels.forEach(function (p) { p.classList.remove('active'); });

          this.classList.add('active');
          var targetEl = document.getElementById(targetTab);
          if (targetEl) targetEl.classList.add('active');
        });
      });
    },

    bindColorInputs: function () {
      var self = this;

      // Color picker input (palette)
      document.addEventListener('input', function (e) {
        if (e.target && e.target.classList.contains('ms-color-input')) {
          var varName = e.target.dataset.var;
          var val = e.target.value;

          // Sync hex text field in same wrapper
          var wrap = e.target.closest('.ms-picker-wrap');
          if (wrap) {
            var hexInput = wrap.querySelector('.ms-hex-text');
            if (hexInput) hexInput.value = val.toUpperCase();
          }

          self.setVariableColor(varName, val);
        }
      });

      // Hex text input (typed)
      document.addEventListener('input', function (e) {
        if (e.target && e.target.classList.contains('ms-hex-text')) {
          var varName = e.target.dataset.var;
          var val = e.target.value.trim();

          if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
            var wrap = e.target.closest('.ms-picker-wrap');
            if (wrap) {
              var colorInput = wrap.querySelector('.ms-color-input');
              if (colorInput) colorInput.value = val;
            }
            self.setVariableColor(varName, val);
          }
        }
      });
    },

    applyPreset: function (presetKey) {
      if (!PRESETS_DATA[presetKey]) return;
      this.currentPreset = presetKey;
      var p = PRESETS_DATA[presetKey];

      // Update active cards
      var cards = document.querySelectorAll('.ms-admin-preset-card');
      cards.forEach(function (card) {
        if (card.dataset.preset === presetKey) {
          card.classList.add('active');
        } else {
          card.classList.remove('active');
        }
      });

      // Update inputs & preview
      for (var varName in p.colors) {
        if (p.colors.hasOwnProperty(varName)) {
          var val = p.colors[varName];
          this.setVariableColor(varName, val, false);

          // Update input controls in DOM
          var colorInput = document.querySelector('.ms-color-input[data-var="' + varName + '"]');
          var hexInput = document.querySelector('.ms-hex-text[data-var="' + varName + '"]');
          if (colorInput) colorInput.value = val;
          if (hexInput) hexInput.value = val.toUpperCase();
        }
      }

      this.updateWCAG();
      this.updateGeneratedCSS();
    },

    setVariableColor: function (varName, value, triggerFullUpdate) {
      if (triggerFullUpdate === undefined) triggerFullUpdate = true;
      this.currentColors[varName] = value;

      // Update Live Mock Site CSS variables
      var mockSite = document.getElementById('ms-mock-site');
      if (mockSite) {
        mockSite.style.setProperty(varName, value);
      }

      // Also set on root so standalone view adapts
      document.documentElement.style.setProperty(varName, value);

      if (triggerFullUpdate) {
        this.updateWCAG();
        this.updateGeneratedCSS();
      }
    },

    bindDeviceSwitcher: function () {
      var btns = document.querySelectorAll('.ms-device-btn');
      var stage = document.getElementById('ms-preview-stage');

      btns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          btns.forEach(function (b) { b.classList.remove('active'); });
          this.classList.add('active');

          var device = this.dataset.device;
          if (stage) {
            stage.className = 'ms-preview-stage ms-device-' + device;
          }
        });
      });
    },

    bindDarkModePreview: function () {
      var self = this;
      var btn = document.getElementById('ms-btn-preview-dark');
      var text = document.getElementById('ms-preview-dark-text');
      var mockSite = document.getElementById('ms-mock-site');

      if (btn) {
        btn.addEventListener('click', function () {
          self.isDarkPreview = !self.isDarkPreview;
          if (self.isDarkPreview) {
            if (mockSite) mockSite.classList.add('ms-dark-mode');
            if (text) text.textContent = 'Tắt Xem Trước Dark Mode';
            btn.classList.add('ms-btn-primary');
            btn.classList.remove('ms-btn-outline');
          } else {
            if (mockSite) mockSite.classList.remove('ms-dark-mode');
            if (text) text.textContent = 'Bật Xem Trước Dark Mode';
            btn.classList.remove('ms-btn-primary');
            btn.classList.add('ms-btn-outline');
          }
        });
      }
    },

    // WCAG 2.1 Contrast Calculation Utilities
    getLuminance: function (hexColor) {
      var rgb = this.hexToRgb(hexColor);
      if (!rgb) return 0;
      var a = [rgb.r, rgb.g, rgb.b].map(function (v) {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      });
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    },

    getContrastRatio: function (hex1, hex2) {
      var lum1 = this.getLuminance(hex1);
      var lum2 = this.getLuminance(hex2);
      var brightest = Math.max(lum1, lum2);
      var darkest = Math.min(lum1, lum2);
      return (brightest + 0.05) / (darkest + 0.05);
    },

    hexToRgb: function (hex) {
      if (!hex) return null;
      hex = hex.replace('#', '');
      if (hex.length === 3) {
        hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
      }
      var num = parseInt(hex, 16);
      if (isNaN(num)) return null;
      return {
        r: (num >> 16) & 255,
        g: (num >> 8) & 255,
        b: num & 255
      };
    },

    updateWCAG: function () {
      var textPrimary = this.currentColors['--ms-text-primary'] || '#0f172a';
      var bg = this.currentColors['--ms-bg'] || '#f8fafc';
      var btnText = this.currentColors['--ms-btn-text'] || '#ffffff';
      var btnBg = this.currentColors['--ms-btn-bg'] || '#2563eb';
      var headerText = this.currentColors['--ms-header-text'] || '#0f172a';
      var headerBg = this.currentColors['--ms-header-bg'] || '#ffffff';
      var footerText = this.currentColors['--ms-footer-text'] || '#f8fafc';
      var footerBg = this.currentColors['--ms-footer-bg'] || '#0f172a';

      var bodyRatio = this.getContrastRatio(textPrimary, bg);
      var btnRatio = this.getContrastRatio(btnText, btnBg);
      var headerRatio = this.getContrastRatio(headerText, headerBg);
      var footerRatio = this.getContrastRatio(footerText, footerBg);

      var ratioEl = document.getElementById('ms-wcag-ratio');
      var verdictEl = document.getElementById('ms-wcag-verdict');

      if (ratioEl) ratioEl.textContent = bodyRatio.toFixed(1) + ':1';
      if (verdictEl) {
        if (bodyRatio >= 7.0) {
          verdictEl.textContent = 'Đạt Chuẩn AAA (Xuất sắc)';
          verdictEl.style.color = '#059669';
        } else if (bodyRatio >= 4.5) {
          verdictEl.textContent = 'Đạt Chuẩn AA (Tốt & Rõ nét)';
          verdictEl.style.color = '#059669';
        } else {
          verdictEl.textContent = 'Chưa Đạt Chuẩn (< 4.5:1)';
          verdictEl.style.color = '#dc2626';
        }
      }

      this.updatePill('wcag-body-status', bodyRatio);
      this.updatePill('wcag-btn-status', btnRatio);
      this.updatePill('wcag-header-status', headerRatio);
      this.updatePill('wcag-footer-status', footerRatio);
    },

    updatePill: function (elementId, ratio) {
      var item = document.getElementById(elementId);
      if (!item) return;
      var pill = item.querySelector('.ms-wcag-pill');
      if (!pill) return;

      if (ratio >= 7.0) {
        pill.className = 'ms-wcag-pill pass';
        pill.textContent = 'AAA (' + ratio.toFixed(1) + ':1)';
      } else if (ratio >= 4.5) {
        pill.className = 'ms-wcag-pill pass';
        pill.textContent = 'AA (' + ratio.toFixed(1) + ':1)';
      } else {
        pill.className = 'ms-wcag-pill fail';
        pill.textContent = 'Fail (' + ratio.toFixed(1) + ':1)';
      }
    },

    updateGeneratedCSS: function () {
      var cssCodeEl = document.getElementById('ms-generated-css');
      if (!cssCodeEl) return;

      var lines = [
        '/* ===================================================',
        '   Plugin MauSac - Generated CSS Variables',
        '   Preset: ' + (PRESETS_DATA[this.currentPreset] ? PRESETS_DATA[this.currentPreset].name : 'Custom'),
        '   =================================================== */',
        ':root {'
      ];

      for (var varName in this.currentColors) {
        if (this.currentColors.hasOwnProperty(varName)) {
          lines.push('  ' + varName + ': ' + this.currentColors[varName] + ';');
        }
      }
      lines.push('}');

      cssCodeEl.textContent = lines.join('\n');
    },

    bindExportImport: function () {
      var self = this;

      // Copy CSS
      var btnCopy = document.getElementById('ms-btn-copy-css');
      if (btnCopy) {
        btnCopy.addEventListener('click', function () {
          var codeEl = document.getElementById('ms-generated-css');
          if (codeEl) {
            navigator.clipboard.writeText(codeEl.textContent).then(function () {
              self.showToast('Đã sao chép mã CSS vào bộ nhớ tạm!');
            });
          }
        });
      }

      // Export JSON
      var btnExportJson = document.getElementById('ms-btn-export-json');
      if (btnExportJson) {
        btnExportJson.addEventListener('click', function () {
          var data = {
            plugin: 'plugin-mausac',
            version: '1.0.0',
            exported_at: new Date().toISOString(),
            active_preset: self.currentPreset,
            colors: self.currentColors
          };

          var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'mausac-theme-config.json';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          self.showToast('Đã xuất file cấu hình JSON thành công!');
        });
      }

      // Import JSON
      var btnTriggerImport = document.getElementById('ms-btn-trigger-import');
      var fileInput = document.getElementById('ms-import-file');
      if (btnTriggerImport && fileInput) {
        btnTriggerImport.addEventListener('click', function () {
          fileInput.click();
        });

        fileInput.addEventListener('change', function (e) {
          var file = e.target.files[0];
          if (!file) return;

          var reader = new FileReader();
          reader.onload = function (event) {
            try {
              var json = JSON.parse(event.target.result);
              if (json.colors) {
                for (var key in json.colors) {
                  if (json.colors.hasOwnProperty(key)) {
                    self.setVariableColor(key, json.colors[key], false);
                    var ci = document.querySelector('.ms-color-input[data-var="' + key + '"]');
                    var hi = document.querySelector('.ms-hex-text[data-var="' + key + '"]');
                    if (ci) ci.value = json.colors[key];
                    if (hi) hi.value = json.colors[key].toUpperCase();
                  }
                }
                self.updateWCAG();
                self.updateGeneratedCSS();
                self.showToast('Đã nạp file cấu hình JSON thành công!');
              }
            } catch (err) {
              alert('File JSON không hợp lệ!');
            }
          };
          reader.readAsText(file);
        });
      }
    },

    bindSaveAndReset: function () {
      var self = this;
      var btnSave = document.getElementById('ms-btn-admin-save');
      var btnReset = document.getElementById('ms-btn-admin-reset');

      if (btnSave) {
        btnSave.addEventListener('click', function () {
          btnSave.classList.add('ms-loading');

          var payload = {
            enabled: true,
            active_preset: self.currentPreset,
            widget_enabled: document.getElementById('ms-setting-widget-enabled') ? document.getElementById('ms-setting-widget-enabled').checked : true,
            widget_position: document.getElementById('ms-setting-widget-pos') ? document.getElementById('ms-setting-widget-pos').value : 'bottom-right',
            enable_dark_mode: document.getElementById('ms-setting-enable-dark') ? document.getElementById('ms-setting-enable-dark').checked : true,
            allow_visitor_override: document.getElementById('ms-setting-save-local') ? document.getElementById('ms-setting-save-local').checked : true,
            colors: self.currentColors
          };

          // If inside WordPress Admin environment
          if (window.MausacAdminData && window.MausacAdminData.ajaxUrl) {
            var formData = new FormData();
            formData.append('action', 'mausac_save_settings');
            formData.append('nonce', window.MausacAdminData.nonce);
            formData.append('settings', JSON.stringify(payload));

            fetch(window.MausacAdminData.ajaxUrl, {
              method: 'POST',
              body: formData
            })
            .then(function (res) { return res.json(); })
            .then(function (res) {
              btnSave.classList.remove('ms-loading');
              if (res.success) {
                self.showToast(window.MausacAdminData.strings.saved || 'Đã lưu cài đặt thành công!');
              } else {
                alert(res.data.message || 'Lỗi lưu cấu hình');
              }
            })
            .catch(function () {
              btnSave.classList.remove('ms-loading');
              self.showToast('Đã lưu cài đặt (chế độ cục bộ)!');
            });
          } else {
            // Standalone Fallback
            setTimeout(function () {
              localStorage.setItem('mausac_customizer_saved', JSON.stringify({
                preset: self.currentPreset,
                colors: self.currentColors
              }));
              btnSave.classList.remove('ms-loading');
              self.showToast('Đã lưu cấu hình màu sắc thành công!');
            }, 500);
          }
        });
      }

      if (btnReset) {
        btnReset.addEventListener('click', function () {
          if (confirm('Bạn có chắc chắn muốn khôi phục về cài đặt gốc?')) {
            self.applyPreset('modern-blue');
            self.showToast('Đã khôi phục cài đặt gốc!');
          }
        });
      }
    },

    showToast: function (message) {
      var toast = document.getElementById('ms-toast');
      var msgEl = document.getElementById('ms-toast-msg');
      if (toast && msgEl) {
        msgEl.textContent = message;
        toast.classList.add('show');
        setTimeout(function () {
          toast.classList.remove('show');
        }, 3000);
      }
    }
  };

  // Expose and auto-init
  window.MauSacAdmin = MauSacAdmin;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      MauSacAdmin.init();
    });
  } else {
    MauSacAdmin.init();
  }
})();
