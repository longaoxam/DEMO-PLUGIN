<?php

/**
 * Plugin Name:       Plugin Màu Sắc Website - Color & Theme Customizer Pro
 * Plugin URI:        https://example.com/plugin-mausac
 * Description:       Plugin chuyên nghiệp cho phép tùy chỉnh màu sắc toàn bộ website, quản lý Dark/Light mode, tích hợp 12+ bộ màu UI/UX cao cấp và Floating Color Switcher widget cho khách truy cập.
 * Version:           1.0.0
 * Author:            Antigravity Studio
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       plugin-mausac
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define Plugin Constants
define('MAUSAC_VERSION', '1.0.0');
define('MAUSAC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MAUSAC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MAUSAC_PLUGIN_FILE', __FILE__);

/**
 * The code that runs during plugin activation.
 */
function activate_plugin_mausac()
{
    $default_options = array(
        'enabled'                => true,
        'active_preset'          => 'modern-blue',
        'widget_enabled'         => true,
        'widget_position'        => 'bottom-right',
        'enable_dark_mode'       => true,
        'allow_visitor_override' => true,
        'colors'                 => array(
            '--ms-primary'         => '#2563eb',
            '--ms-primary-hover'   => '#1d4ed8',
            '--ms-secondary'       => '#06b6d4',
            '--ms-accent'          => '#f59e0b',
            '--ms-bg'              => '#f8fafc',
            '--ms-surface'         => '#ffffff',
            '--ms-surface-border'  => '#e2e8f0',
            '--ms-text-primary'    => '#0f172a',
            '--ms-text-secondary'  => '#64748b',
            '--ms-header-bg'       => '#ffffff',
            '--ms-header-text'     => '#0f172a',
            '--ms-footer-bg'       => '#0f172a',
            '--ms-footer-text'     => '#f8fafc',
            '--ms-btn-bg'          => '#2563eb',
            '--ms-btn-text'        => '#ffffff'
        ),
        'created_at'             => current_time('mysql')
    );

    if (!get_option('mausac_customizer_options')) {
        update_option('mausac_customizer_options', $default_options);
    }
}
register_activation_hook(__FILE__, 'activate_plugin_mausac');

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_plugin_mausac()
{
    // Keep options for reactivation unless uninstalled
}
register_deactivation_hook(__FILE__, 'deactivate_plugin_mausac');

// Require includes
require_once MAUSAC_PLUGIN_DIR . 'includes/class-mausac-admin.php';
require_once MAUSAC_PLUGIN_DIR . 'includes/class-mausac-frontend.php';

/**
 * Initialize Plugin Core
 */
function run_plugin_mausac()
{
    if (is_admin()) {
        MauSac_Admin::get_instance();
    }
    MauSac_Frontend::get_instance();
}
add_action('plugins_loaded', 'run_plugin_mausac');

/**
 * Add settings action link to plugins list page
 */
function mausac_add_action_links($links)
{
    $settings_link = '<a href="' . admin_url('admin.php?page=plugin-mausac') . '">' . __('Cài đặt Màu sắc', 'plugin-mausac') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'mausac_add_action_links');
