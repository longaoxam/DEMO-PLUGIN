/**
 * Universal Standalone Color Customizer Library
 * Plug & play JS engine for theme switching, floating widget, and presets.
 */

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.MauSacPlugin = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var PRESETS = {
    'modern-blue': {
      name: 'Modern Blue',
      preview: ['#2563eb', '#06b6d4', '#ffffff', '#0f172a'],
      colors: {
        '--ms-primary': '#2563eb',
        '--ms-primary-hover': '#1d4ed8',
        '--ms-secondary': '#06b6d4',
        '--ms-accent': '#f59e0b',
        '--ms-bg': '#f8fafc',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e2e8f0',
        '--ms-text-primary': '#0f172a',
        '--ms-text-secondary': '#64748b',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#0f172a',
        '--ms-footer-bg': '#0f172a',
        '--ms-footer-text': '#f8fafc',
        '--ms-btn-bg': '#2563eb',
        '--ms-btn-text': '#ffffff'
      }
    },
    'emerald-luxury': {
      name: 'Emerald Luxury',
      preview: ['#059669', '#10b981', '#ffffff', '#064e3b'],
      colors: {
        '--ms-primary': '#059669',
        '--ms-primary-hover': '#047857',
        '--ms-secondary': '#10b981',
        '--ms-accent': '#10b981',
        '--ms-bg': '#f0fdf4',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#dcfce7',
        '--ms-text-primary': '#064e3b',
        '--ms-text-secondary': '#047857',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#064e3b',
        '--ms-footer-bg': '#022c22',
        '--ms-footer-text': '#f0fdf4',
        '--ms-btn-bg': '#059669',
        '--ms-btn-text': '#ffffff'
      }
    },
    'cyberpunk-dark': {
      name: 'Cyberpunk Dark',
      preview: ['#f43f5e', '#a855f7', '#111827', '#f3f4f6'],
      colors: {
        '--ms-primary': '#f43f5e',
        '--ms-primary-hover': '#e11d48',
        '--ms-secondary': '#a855f7',
        '--ms-accent': '#06b6d4',
        '--ms-bg': '#090d16',
        '--ms-surface': '#111827',
        '--ms-surface-border': '#1f2937',
        '--ms-text-primary': '#f3f4f6',
        '--ms-text-secondary': '#9ca3af',
        '--ms-header-bg': '#0f172a',
        '--ms-header-text': '#f8fafc',
        '--ms-footer-bg': '#030712',
        '--ms-footer-text': '#9ca3af',
        '--ms-btn-bg': '#f43f5e',
        '--ms-btn-text': '#ffffff'
      }
    },
    'sunset-warmth': {
      name: 'Sunset Warmth',
      preview: ['#ea580c', '#f59e0b', '#ffffff', '#431407'],
      colors: {
        '--ms-primary': '#ea580c',
        '--ms-primary-hover': '#c2410c',
        '--ms-secondary': '#f59e0b',
        '--ms-accent': '#f59e0b',
        '--ms-bg': '#fffbeb',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fef3c7',
        '--ms-text-primary': '#431407',
        '--ms-text-secondary': '#78350f',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#431407',
        '--ms-footer-bg': '#1c1917',
        '--ms-footer-text': '#fffbeb',
        '--ms-btn-bg': '#ea580c',
        '--ms-btn-text': '#ffffff'
      }
    },
    'royal-purple': {
      name: 'Royal Purple',
      preview: ['#7c3aed', '#ec4899', '#ffffff', '#3b0764'],
      colors: {
        '--ms-primary': '#7c3aed',
        '--ms-primary-hover': '#6d28d9',
        '--ms-secondary': '#ec4899',
        '--ms-accent': '#ec4899',
        '--ms-bg': '#faf5ff',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#f3e8ff',
        '--ms-text-primary': '#3b0764',
        '--ms-text-secondary': '#6b21a8',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#3b0764',
        '--ms-footer-bg': '#1e1b4b',
        '--ms-footer-text': '#faf5ff',
        '--ms-btn-bg': '#7c3aed',
        '--ms-btn-text': '#ffffff'
      }
    },
    'ocean-breeze': {
      name: 'Ocean Breeze',
      preview: ['#0284c7', '#14b8a6', '#ffffff', '#0c4a6e'],
      colors: {
        '--ms-primary': '#0284c7',
        '--ms-primary-hover': '#0369a1',
        '--ms-secondary': '#14b8a6',
        '--ms-accent': '#14b8a6',
        '--ms-bg': '#f0f9ff',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e0f2fe',
        '--ms-text-primary': '#0c4a6e',
        '--ms-text-secondary': '#0369a1',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#0c4a6e',
        '--ms-footer-bg': '#082f49',
        '--ms-footer-text': '#f0f9ff',
        '--ms-btn-bg': '#0284c7',
        '--ms-btn-text': '#ffffff'
      }
    }
  };

  var STORAGE_KEY = 'mausac_customizer_saved';
  var DARK_MODE_KEY = 'mausac_dark_mode';

  function MauSacPluginInstance(options) {
    this.options = Object.assign({
      widget: true,
      position: 'bottom-right',
      defaultTheme: 'modern-blue',
      enableDarkMode: true
    }, options);

    this.init();
  }

  MauSacPluginInstance.prototype.init = function () {
    var self = this;
    setTimeout(function () { document.body.classList.add('ms-animated'); }, 100);

    // Check dark mode
    if (localStorage.getItem(DARK_MODE_KEY) === 'true') {
      document.body.classList.add('ms-dark-mode');
      document.documentElement.setAttribute('data-ms-theme', 'dark');
    }

    // Check saved theme
    var saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        var parsed = JSON.parse(saved);
        if (parsed.colors) this.applyColors(parsed.colors);
      } catch (e) {}
    } else if (this.options.defaultTheme && PRESETS[this.options.defaultTheme]) {
      this.applyColors(PRESETS[this.options.defaultTheme].colors);
    }

    if (this.options.widget) {
      this.createWidget();
    }
  };

  MauSacPluginInstance.prototype.applyColors = function (colors) {
    var root = document.documentElement;
    for (var key in colors) {
      if (colors.hasOwnProperty(key)) {
        root.style.setProperty(key, colors[key]);
      }
    }
  };

  MauSacPluginInstance.prototype.setTheme = function (themeKey) {
    if (PRESETS[themeKey]) {
      this.applyColors(PRESETS[themeKey].colors);
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        preset: themeKey,
        colors: PRESETS[themeKey].colors
      }));
    }
  };

  MauSacPluginInstance.prototype.toggleDarkMode = function (isDark) {
    var dark = typeof isDark === 'boolean' ? isDark : !document.body.classList.contains('ms-dark-mode');
    if (dark) {
      document.body.classList.add('ms-dark-mode');
      document.documentElement.setAttribute('data-ms-theme', 'dark');
      localStorage.setItem(DARK_MODE_KEY, 'true');
    } else {
      document.body.classList.remove('ms-dark-mode');
      document.documentElement.removeAttribute('data-ms-theme');
      localStorage.setItem(DARK_MODE_KEY, 'false');
    }
  };

  MauSacPluginInstance.prototype.createWidget = function () {
    if (document.getElementById('ms-floating-widget')) return;
    var self = this;
    var isDark = document.body.classList.contains('ms-dark-mode');

    var wrap = document.createElement('div');
    wrap.id = 'ms-floating-widget';
    wrap.className = 'ms-floating-widget-wrapper ms-pos-' + (this.options.position || 'bottom-right');

    wrap.innerHTML = [
      '<button class="ms-widget-trigger" title="Đổi Màu Giao Diện">',
      '  <svg viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L4.35 19.4c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l1.9-1.9C9.28 19.57 10.59 20 12 20c4.97 0 9-4.03 9-9s-4.03-9-9-9zm0 15c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/><circle cx="8" cy="11" r="1.5"/><circle cx="12" cy="8" r="1.5"/><circle cx="16" cy="11" r="1.5"/><circle cx="14" cy="15" r="1.5"/><circle cx="10" cy="15" r="1.5"/></svg>',
      '</button>',
      '<div class="ms-widget-panel">',
      '  <div class="ms-panel-header">',
      '    <h4 class="ms-panel-title">Tùy Chọn Màu</h4>',
      '    <span class="ms-panel-badge">Theme</span>',
      '  </div>',
      '  <div class="ms-panel-mode-row">',
      '    <span class="ms-mode-label">Chế độ Tối</span>',
      '    <label class="ms-toggle-switch">',
      '      <input type="checkbox" id="ms-dark-toggle" ' + (isDark ? 'checked' : '') + '>',
      '      <span class="ms-toggle-slider"></span>',
      '    </label>',
      '  </div>',
      '  <div class="ms-presets-section-title">Bảng Màu Thiết Kế Sẵn</div>',
      '  <div class="ms-presets-grid" id="ms-presets-container"></div>',
      '  <div class="ms-panel-actions">',
      '    <button class="ms-panel-btn" id="ms-btn-reset">Khôi phục mặc định</button>',
      '  </div>',
      '</div>'
    ].join('\n');

    document.body.appendChild(wrap);

    var grid = document.getElementById('ms-presets-container');
    for (var key in PRESETS) {
      if (PRESETS.hasOwnProperty(key)) {
        var card = document.createElement('div');
        card.className = 'ms-preset-card';
        card.dataset.preset = key;
        card.title = PRESETS[key].name;
        card.innerHTML = PRESETS[key].preview.map(function(c){ return '<div class="ms-p-color" style="background:'+c+'"></div>'; }).join('');
        grid.appendChild(card);
      }
    }

    // Events
    wrap.querySelector('.ms-widget-trigger').addEventListener('click', function(e) {
      wrap.classList.toggle('ms-open');
      e.stopPropagation();
    });

    document.addEventListener('click', function(e) {
      if (!wrap.contains(e.target)) wrap.classList.remove('ms-open');
    });

    var dt = document.getElementById('ms-dark-toggle');
    if (dt) dt.addEventListener('change', function(e) { self.toggleDarkMode(e.target.checked); });

    grid.addEventListener('click', function(e) {
      var c = e.target.closest('.ms-preset-card');
      if (c && c.dataset.preset) {
        self.setTheme(c.dataset.preset);
        grid.querySelectorAll('.ms-preset-card').forEach(function(el){ el.classList.remove('ms-active'); });
        c.classList.add('ms-active');
      }
    });

    document.getElementById('ms-btn-reset').addEventListener('click', function() {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(DARK_MODE_KEY);
      document.body.classList.remove('ms-dark-mode');
      document.documentElement.removeAttribute('data-ms-theme');
      if (dt) dt.checked = false;
      self.setTheme('modern-blue');
    });
  };

  return {
    init: function (opts) {
      return new MauSacPluginInstance(opts);
    },
    presets: PRESETS
  };
}));
