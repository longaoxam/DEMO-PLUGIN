<?php
/**
 * Handles all Frontend rendering, dynamic CSS injection, and widget loading.
 *
 * @package PluginMauSac
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class MauSac_Frontend {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('wp_head', array($this, 'inject_custom_css_variables'), 99);
    }

    /**
     * Enqueue Frontend CSS and JS
     */
    public function enqueue_frontend_assets() {
        $options = get_option('mausac_customizer_options', array());
        $is_enabled = isset($options['enabled']) ? $options['enabled'] : true;

        if (!$is_enabled) {
            return;
        }

        wp_enqueue_style(
            'mausac-frontend-style',
            MAUSAC_PLUGIN_URL . 'public/css/frontend-style.css',
            array(),
            MAUSAC_VERSION
        );

        wp_enqueue_script(
            'mausac-frontend-script',
            MAUSAC_PLUGIN_URL . 'public/js/frontend-script.js',
            array(),
            MAUSAC_VERSION,
            true
        );

        // Localize configuration for the JS frontend
        $config = array(
            'enabled'               => true,
            'widgetEnabled'         => isset($options['widget_enabled']) ? (bool)$options['widget_enabled'] : true,
            'widgetPosition'        => isset($options['widget_position']) ? sanitize_text_field($options['widget_position']) : 'bottom-right',
            'defaultTheme'          => isset($options['active_preset']) ? sanitize_text_field($options['active_preset']) : 'modern-blue',
            'enableDarkMode'        => isset($options['enable_dark_mode']) ? (bool)$options['enable_dark_mode'] : true,
            'allowVisitorOverride'  => isset($options['allow_visitor_override']) ? (bool)$options['allow_visitor_override'] : true,
            'defaultColors'         => isset($options['colors']) ? $options['colors'] : array()
        );

        wp_localize_script('mausac-frontend-script', 'MausacCustomizerConfig', $config);
    }

    /**
     * Injects the dynamic CSS variables generated from admin settings into wp_head
     */
    public function inject_custom_css_variables() {
        $options = get_option('mausac_customizer_options', array());
        $is_enabled = isset($options['enabled']) ? $options['enabled'] : true;

        if (!$is_enabled) {
            return;
        }

        $colors = isset($options['colors']) ? $options['colors'] : array();
        $custom_css = isset($options['custom_css']) ? $options['custom_css'] : '';

        // Default fallbacks
        $defaults = array(
            '--ms-primary'          => '#2563eb',
            '--ms-primary-hover'    => '#1d4ed8',
            '--ms-secondary'        => '#06b6d4',
            '--ms-secondary-hover'  => '#0891b2',
            '--ms-bg'               => '#f8fafc',
            '--ms-surface'          => '#ffffff',
            '--ms-surface-border'   => '#e2e8f0',
            '--ms-text-primary'     => '#0f172a',
            '--ms-text-secondary'   => '#64748b',
            '--ms-header-bg'        => '#ffffff',
            '--ms-header-text'      => '#0f172a',
            '--ms-footer-bg'        => '#0f172a',
            '--ms-footer-text'      => '#f8fafc',
            '--ms-btn-bg'           => '#2563eb',
            '--ms-btn-text'         => '#ffffff',
            '--ms-accent'           => '#f59e0b'
        );

        $merged_colors = wp_parse_args($colors, $defaults);

        echo "\n<!-- Plugin MauSac - Dynamic Theme CSS Variables -->\n";
        echo "<style id=\"mausac-customizer-injected-css\">\n";
        echo ":root {\n";
        foreach ($merged_colors as $var_name => $color_value) {
            if (!empty($color_value)) {
                echo '  ' . esc_attr($var_name) . ': ' . esc_attr($color_value) . ";\n";
            }
        }
        echo "}\n";

        // If user provided additional custom CSS
        if (!empty($custom_css)) {
            echo "\n/* Custom User Overrides */\n";
            echo wp_strip_all_tags($custom_css) . "\n";
        }

        echo "</style>\n";
    }
}
