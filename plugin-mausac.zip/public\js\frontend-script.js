/**
 * Plugin MauSac - Frontend Script
 * Manages visitor color customization, floating widget, localStorage persistence, and live transitions.
 */

(function () {
  'use strict';

  // Default Preset Palettes definitions
  var PRESETS = {
    'modern-blue': {
      name: 'Xanh Công Nghệ (Modern Blue)',
      colors: {
        '--ms-primary': '#2563eb',
        '--ms-primary-hover': '#1d4ed8',
        '--ms-secondary': '#06b6d4',
        '--ms-secondary-hover': '#0891b2',
        '--ms-bg': '#f8fafc',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e2e8f0',
        '--ms-text-primary': '#0f172a',
        '--ms-text-secondary': '#64748b',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#0f172a',
        '--ms-footer-bg': '#0f172a',
        '--ms-footer-text': '#f8fafc',
        '--ms-btn-bg': '#2563eb',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#f59e0b'
      },
      preview: ['#2563eb', '#06b6d4', '#ffffff', '#0f172a']
    },
    'emerald-luxury': {
      name: 'Ngọc Lục Bảo (Emerald Luxury)',
      colors: {
        '--ms-primary': '#059669',
        '--ms-primary-hover': '#047857',
        '--ms-secondary': '#10b981',
        '--ms-secondary-hover': '#059669',
        '--ms-bg': '#f0fdf4',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#dcfce7',
        '--ms-text-primary': '#064e3b',
        '--ms-text-secondary': '#047857',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#064e3b',
        '--ms-footer-bg': '#022c22',
        '--ms-footer-text': '#f0fdf4',
        '--ms-btn-bg': '#059669',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#10b981'
      },
      preview: ['#059669', '#10b981', '#ffffff', '#064e3b']
    },
    'cyberpunk-dark': {
      name: 'Đêm Tương Lai (Cyberpunk Dark)',
      colors: {
        '--ms-primary': '#f43f5e',
        '--ms-primary-hover': '#e11d48',
        '--ms-secondary': '#a855f7',
        '--ms-secondary-hover': '#9333ea',
        '--ms-bg': '#090d16',
        '--ms-surface': '#111827',
        '--ms-surface-border': '#1f2937',
        '--ms-text-primary': '#f3f4f6',
        '--ms-text-secondary': '#9ca3af',
        '--ms-header-bg': '#0f172a',
        '--ms-header-text': '#f8fafc',
        '--ms-footer-bg': '#030712',
        '--ms-footer-text': '#9ca3af',
        '--ms-btn-bg': '#f43f5e',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#06b6d4'
      },
      preview: ['#f43f5e', '#a855f7', '#111827', '#f3f4f6']
    },
    'sunset-warmth': {
      name: 'Hoàng Hôn Rực Rỡ (Sunset Warmth)',
      colors: {
        '--ms-primary': '#ea580c',
        '--ms-primary-hover': '#c2410c',
        '--ms-secondary': '#f59e0b',
        '--ms-secondary-hover': '#d97706',
        '--ms-bg': '#fffbeb',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fef3c7',
        '--ms-text-primary': '#431407',
        '--ms-text-secondary': '#78350f',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#431407',
        '--ms-footer-bg': '#1c1917',
        '--ms-footer-text': '#fffbeb',
        '--ms-btn-bg': '#ea580c',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#f59e0b'
      },
      preview: ['#ea580c', '#f59e0b', '#ffffff', '#431407']
    },
    'royal-purple': {
      name: 'Tím Hoàng Gia (Royal Purple)',
      colors: {
        '--ms-primary': '#7c3aed',
        '--ms-primary-hover': '#6d28d9',
        '--ms-secondary': '#ec4899',
        '--ms-secondary-hover': '#db2777',
        '--ms-bg': '#faf5ff',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#f3e8ff',
        '--ms-text-primary': '#3b0764',
        '--ms-text-secondary': '#6b21a8',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#3b0764',
        '--ms-footer-bg': '#1e1b4b',
        '--ms-footer-text': '#faf5ff',
        '--ms-btn-bg': '#7c3aed',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#ec4899'
      },
      preview: ['#7c3aed', '#ec4899', '#ffffff', '#3b0764']
    },
    'ocean-breeze': {
      name: 'Gió Biển Tươi Mát (Ocean Breeze)',
      colors: {
        '--ms-primary': '#0284c7',
        '--ms-primary-hover': '#0369a1',
        '--ms-secondary': '#14b8a6',
        '--ms-secondary-hover': '#0d9488',
        '--ms-bg': '#f0f9ff',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#e0f2fe',
        '--ms-text-primary': '#0c4a6e',
        '--ms-text-secondary': '#0369a1',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#0c4a6e',
        '--ms-footer-bg': '#082f49',
        '--ms-footer-text': '#f0f9ff',
        '--ms-btn-bg': '#0284c7',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#14b8a6'
      },
      preview: ['#0284c7', '#14b8a6', '#ffffff', '#0c4a6e']
    },
    'crimson-passion': {
      name: 'Đỏ Đam Mê (Crimson Passion)',
      colors: {
        '--ms-primary': '#dc2626',
        '--ms-primary-hover': '#b91c1c',
        '--ms-secondary': '#f97316',
        '--ms-secondary-hover': '#ea580c',
        '--ms-bg': '#fef2f2',
        '--ms-surface': '#ffffff',
        '--ms-surface-border': '#fee2e2',
        '--ms-text-primary': '#450a0a',
        '--ms-text-secondary': '#991b1b',
        '--ms-header-bg': '#ffffff',
        '--ms-header-text': '#450a0a',
        '--ms-footer-bg': '#1c1917',
        '--ms-footer-text': '#fef2f2',
        '--ms-btn-bg': '#dc2626',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#f97316'
      },
      preview: ['#dc2626', '#f97316', '#ffffff', '#450a0a']
    },
    'midnight-obsidian': {
      name: 'Hắc Ngọc Tối (Midnight Obsidian)',
      colors: {
        '--ms-primary': '#6366f1',
        '--ms-primary-hover': '#4f46e5',
        '--ms-secondary': '#818cf8',
        '--ms-secondary-hover': '#6366f1',
        '--ms-bg': '#0b0f19',
        '--ms-surface': '#151c2e',
        '--ms-surface-border': '#1e293b',
        '--ms-text-primary': '#f8fafc',
        '--ms-text-secondary': '#94a3b8',
        '--ms-header-bg': '#0f172a',
        '--ms-header-text': '#f8fafc',
        '--ms-footer-bg': '#020617',
        '--ms-footer-text': '#94a3b8',
        '--ms-btn-bg': '#6366f1',
        '--ms-btn-text': '#ffffff',
        '--ms-accent': '#818cf8'
      },
      preview: ['#6366f1', '#818cf8', '#151c2e', '#f8fafc']
    }
  };

  var STORAGE_KEY = 'mausac_customizer_saved';
  var DARK_MODE_KEY = 'mausac_dark_mode';

  var MauSacFrontend = {
    config: window.MausacCustomizerConfig || {
      enabled: true,
      widgetEnabled: true,
      widgetPosition: 'bottom-right',
      defaultTheme: 'modern-blue',
      enableDarkMode: true,
      allowVisitorOverride: true
    },

    init: function () {
      this.enableAnimation();
      this.loadSavedSettings();
      if (this.config.widgetEnabled) {
        this.renderWidget();
      }
      this.bindEvents();
    },

    enableAnimation: function () {
      // Add animation class after initial load to avoid flash of transitions
      setTimeout(function () {
        document.body.classList.add('ms-animated');
      }, 100);
    },

    loadSavedSettings: function () {
      // Check saved dark mode
      var isDark = localStorage.getItem(DARK_MODE_KEY);
      if (isDark === 'true') {
        document.body.classList.add('ms-dark-mode');
        document.documentElement.setAttribute('data-ms-theme', 'dark');
      }

      // Check saved preset or custom colors
      var saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          var parsed = JSON.parse(saved);
          if (parsed.colors) {
            this.applyColors(parsed.colors);
          }
        } catch (e) {
          console.error('MauSac: Failed to parse saved color settings', e);
        }
      }
    },

    applyColors: function (colorsMap) {
      var root = document.documentElement;
      for (var varName in colorsMap) {
        if (colorsMap.hasOwnProperty(varName)) {
          root.style.setProperty(varName, colorsMap[varName]);
        }
      }
    },

    setPreset: function (presetKey) {
      if (PRESETS[presetKey]) {
        this.applyColors(PRESETS[presetKey].colors);
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          preset: presetKey,
          colors: PRESETS[presetKey].colors
        }));

        // Update active class in widget if present
        var cards = document.querySelectorAll('.ms-preset-card');
        cards.forEach(function (card) {
          if (card.dataset.preset === presetKey) {
            card.classList.add('ms-active');
          } else {
            card.classList.remove('ms-active');
          }
        });
      }
    },

    toggleDarkMode: function (enable) {
      var isDark = typeof enable === 'boolean' ? enable : !document.body.classList.contains('ms-dark-mode');
      if (isDark) {
        document.body.classList.add('ms-dark-mode');
        document.documentElement.setAttribute('data-ms-theme', 'dark');
        localStorage.setItem(DARK_MODE_KEY, 'true');
      } else {
        document.body.classList.remove('ms-dark-mode');
        document.documentElement.removeAttribute('data-ms-theme');
        localStorage.setItem(DARK_MODE_KEY, 'false');
      }
    },

    resetToDefault: function () {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(DARK_MODE_KEY);
      document.body.classList.remove('ms-dark-mode');
      document.documentElement.removeAttribute('data-ms-theme');

      // Clear inline styles
      var root = document.documentElement;
      for (var i = 0; i < root.style.length; i++) {
        var prop = root.style[i];
        if (prop && prop.indexOf('--ms-') === 0) {
          root.style.removeProperty(prop);
        }
      }

      // Re-apply initial config
      if (this.config.defaultColors) {
        this.applyColors(this.config.defaultColors);
      } else if (this.config.defaultTheme && PRESETS[this.config.defaultTheme]) {
        this.applyColors(PRESETS[this.config.defaultTheme].colors);
      }

      // Reset active cards
      var cards = document.querySelectorAll('.ms-preset-card');
      cards.forEach(function (card) {
        card.classList.remove('ms-active');
      });
    },

    renderWidget: function () {
      // Check if widget already exists
      if (document.getElementById('ms-floating-widget')) return;

      var posClass = 'ms-pos-' + (this.config.widgetPosition || 'bottom-right');
      var isDark = document.body.classList.contains('ms-dark-mode');

      var widgetHtml = [
        '<div id="ms-floating-widget" class="ms-floating-widget-wrapper ' + posClass + '">',
        '  <button class="ms-widget-trigger" aria-label="Mở tùy chỉnh màu sắc website" title="Đổi màu giao diện">',
        '    <svg viewBox="0 0 24 24"><path d="M12 3c-4.97 0-9 4.03-9 9 0 2.12.74 4.07 1.97 5.61L4.35 19.4c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0l1.9-1.9C9.28 19.57 10.59 20 12 20c4.97 0 9-4.03 9-9s-4.03-9-9-9zm0 15c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/><circle cx="8" cy="11" r="1.5"/><circle cx="12" cy="8" r="1.5"/><circle cx="16" cy="11" r="1.5"/><circle cx="14" cy="15" r="1.5"/><circle cx="10" cy="15" r="1.5"/></svg>',
        '  </button>',
        '  <div class="ms-widget-panel">',
        '    <div class="ms-panel-header">',
        '      <h4 class="ms-panel-title">',
        '        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 17.93V18a2 2 0 0 1-2-2v-1a2 2 0 0 1 2-2h1a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v1a2 2 0 0 1-2 2H4.07A8 8 0 1 1 13 19.93z"/></svg>',
        '        Tùy Chỉnh Màu',
        '      </h4>',
        '      <span class="ms-panel-badge">Theme</span>',
        '    </div>',
        '    <div class="ms-panel-mode-row">',
        '      <span class="ms-mode-label">Chế độ Tối (Dark Mode)</span>',
        '      <label class="ms-toggle-switch">',
        '        <input type="checkbox" id="ms-dark-toggle" ' + (isDark ? 'checked' : '') + '>',
        '        <span class="ms-toggle-slider"></span>',
        '      </label>',
        '    </div>',
        '    <div class="ms-presets-section-title">Bảng Màu Thiết Kế Sẵn</div>',
        '    <div class="ms-presets-grid" id="ms-presets-container">',
        '    </div>',
        '    <div class="ms-panel-actions">',
        '      <button class="ms-panel-btn" id="ms-btn-reset">',
        '        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>',
        '        Khôi phục gốc',
        '      </button>',
        '    </div>',
        '  </div>',
        '</div>'
      ].join('\n');

      var div = document.createElement('div');
      div.innerHTML = widgetHtml;
      document.body.appendChild(div.firstElementChild);

      // Populate presets in container
      var container = document.getElementById('ms-presets-container');
      var savedObj = null;
      try {
        var s = localStorage.getItem(STORAGE_KEY);
        if (s) savedObj = JSON.parse(s);
      } catch (e) {}

      for (var key in PRESETS) {
        if (PRESETS.hasOwnProperty(key)) {
          var p = PRESETS[key];
          var isActive = savedObj && savedObj.preset === key;
          var card = document.createElement('div');
          card.className = 'ms-preset-card' + (isActive ? ' ms-active' : '');
          card.dataset.preset = key;
          card.title = p.name;

          var previewBars = '';
          p.preview.forEach(function (c) {
            previewBars += '<div class="ms-p-color" style="background-color:' + c + '"></div>';
          });
          card.innerHTML = previewBars;
          container.appendChild(card);
        }
      }
    },

    bindEvents: function () {
      var self = this;

      // Widget Trigger Click
      document.addEventListener('click', function (e) {
        var trigger = e.target.closest('.ms-widget-trigger');
        var widget = document.getElementById('ms-floating-widget');

        if (trigger && widget) {
          widget.classList.toggle('ms-open');
          e.stopPropagation();
          return;
        }

        // Close when clicking outside widget panel
        if (widget && widget.classList.contains('ms-open')) {
          if (!e.target.closest('.ms-widget-panel')) {
            widget.classList.remove('ms-open');
          }
        }
      });

      // Dark Mode Toggle
      document.addEventListener('change', function (e) {
        if (e.target && e.target.id === 'ms-dark-toggle') {
          self.toggleDarkMode(e.target.checked);
        }
      });

      // Preset click
      document.addEventListener('click', function (e) {
        var card = e.target.closest('.ms-preset-card');
        if (card && card.dataset.preset) {
          self.setPreset(card.dataset.preset);
        }

        if (e.target && e.target.id === 'ms-btn-reset') {
          self.resetToDefault();
          var dt = document.getElementById('ms-dark-toggle');
          if (dt) dt.checked = false;
        }
      });

      // Listen to postMessage from Admin Live Preview iframe
      window.addEventListener('message', function (event) {
        if (!event.data || typeof event.data !== 'object') return;

        if (event.data.type === 'MAUSAC_APPLY_COLORS') {
          self.applyColors(event.data.colors);
        } else if (event.data.type === 'MAUSAC_SET_PRESET') {
          self.setPreset(event.data.preset);
        } else if (event.data.type === 'MAUSAC_TOGGLE_DARK') {
          self.toggleDarkMode(event.data.isDark);
        }
      });
    }
  };

  // Expose to window
  window.MauSacFrontend = MauSacFrontend;

  // Auto initialize on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      MauSacFrontend.init();
    });
  } else {
    MauSacFrontend.init();
  }
})();
