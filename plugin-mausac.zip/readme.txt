=== Plugin Màu Sắc Website - Color & Theme Customizer Pro ===
Contributors: antigravity
Tags: color customizer, theme changer, dark mode, colors, palette, styling, css variables
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin chuyên nghiệp cho phép tùy chỉnh màu sắc toàn bộ website theo thời gian thực, tích hợp 12+ bộ màu UI/UX cao cấp, chế độ Sáng/Tối và Widget đổi màu cho khách truy cập.

== Description ==

**Plugin Màu Sắc Website (Color & Theme Customizer Pro)** là giải pháp toàn diện giúp quản trị viên thay đổi nhận diện màu sắc của toàn bộ website chỉ với vài cú nhấp chuột mà không cần biết viết mã code.

### 🌟 Tính Năng Nổi Bật:
* **Dashboard Quản Trị Đỉnh Cao**: Giao diện tab trực quan, hiện đại, xem trước trực tiếp (Live Preview) mọi thay đổi màu sắc trên giao diện mẫu.
* **12+ Bộ Màu Mẫu Cao Cấp**: Tuyển chọn các tone màu thời thượng: Xanh Công Nghệ, Ngọc Lục Bảo, Cyberpunk Dark, Hoàng Hôn Rực Rỡ, Tím Hoàng Gia, Gió Biển Tươi Mát, Kẹo Ngọt Pastel, Vintage Gold, Forest Zen, Monochrome,...
* **Tùy Chỉnh Phân Lớp Toàn Diện**: Chỉnh màu Nền (Background), Nền thẻ (Card), Màu Chữ (Text), Tiêu Đề (Headings), Thanh Điều Hướng (Header), Chân Trang (Footer), Nút Bấm (Buttons) và Đường Viền (Borders).
* **Đo Độ Tương Phản WCAG 2.1**: Tự động tính toán tỉ lệ tương phản chữ và nền để đảm bảo website đạt chuẩn AA/AAA về khả năng đọc và bảo vệ mắt.
* **Floating Switcher Widget**: Widget nổi tròn ở góc trang cho phép khách truy cập tự do đổi màu giao diện hoặc bật/tắt Dark Mode.
* **Tự Động Lưu Trạng Thái**: Sử dụng `localStorage` để ghi nhớ màu yêu thích của từng khách truy cập.
* **Xuất & Nhập Cấu Hình**: Dễ dàng sao lưu cấu hình ra file JSON hoặc sao chép mã CSS Variables nhúng nhanh.

== Installation ==

1. Tải thư mục `plugin-mausac` lên thư mục `/wp-content/plugins/` của website WordPress của bạn (hoặc nén zip rồi tải lên qua trang Admin Plugins).
2. Kích hoạt plugin qua menu **Gói mở rộng (Plugins)** trong WordPress.
3. Điều hướng tới menu **Màu Sắc Web** trên thanh quản trị để bắt đầu tùy biến màu sắc.

== Frequently Asked Questions ==

= Plugin có làm chậm website không? =
Không! Plugin sử dụng thuần túy **CSS Variables** cực kỳ nhẹ, không nạp thư viện nặng nề, đảm bảo tốc độ tải trang 100/100 Google PageSpeed.

= Tôi có thể nhúng vào website không dùng WordPress không? =
Có! Thư mục `standalone/` và file `index.html` được cung cấp sẵn cho phép bạn nhúng trực tiếp vào bất kỳ website HTML, React, Vue, Laravel hoặc PHP thuần nào.

== Changelog ==

= 1.0.0 =
* Phiên bản phát hành đầu tiên với đầy đủ tính năng: 12 Presets, Live Preview, WCAG Checker, Floating Switcher Widget, Export/Import.
