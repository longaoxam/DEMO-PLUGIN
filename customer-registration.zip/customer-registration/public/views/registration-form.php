<?php
/**
 * Frontend Registration Form Shortcode Template [dang_ky_khach_hang]
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="cr-public-form-card">
    <div class="cr-form-header">
        <h3 class="cr-form-title">Đăng Ký Nhận Tư Vấn</h3>
        <p class="cr-form-subtitle">Vui lòng điền thông tin bên dưới, chuyên viên của chúng tôi sẽ liên hệ lại ngay!</p>
    </div>

    <form id="cr-public-registration-form" class="cr-public-form" novalidate>
        <div class="cr-form-response-msg" style="display: none;"></div>

        <div class="cr-input-grid">
            <div class="cr-input-field">
                <label for="cr_pub_fullname">Họ và tên <span class="cr-required">*</span></label>
                <div class="cr-input-wrap">
                    <span class="cr-input-icon">👤</span>
                    <input type="text" id="cr_pub_fullname" name="fullname" placeholder="Nguyễn Văn A" required />
                </div>
            </div>

            <div class="cr-input-field">
                <label for="cr_pub_phone">Số điện thoại <span class="cr-required">*</span></label>
                <div class="cr-input-wrap">
                    <span class="cr-input-icon">📞</span>
                    <input type="tel" id="cr_pub_phone" name="phone" placeholder="0912 345 678" required />
                </div>
            </div>
        </div>

        <div class="cr-input-grid">
            <div class="cr-input-field">
                <label for="cr_pub_email">Địa chỉ Email</label>
                <div class="cr-input-wrap">
                    <span class="cr-input-icon">✉️</span>
                    <input type="email" id="cr_pub_email" name="email" placeholder="example@email.com" />
                </div>
            </div>

            <div class="cr-input-field">
                <label for="cr_pub_service">Dịch vụ quan tâm</label>
                <div class="cr-input-wrap">
                    <span class="cr-input-icon">💼</span>
                    <input type="text" id="cr_pub_service" name="service_needed" placeholder="Ví dụ: Thiết kế Web, Marketing..." />
                </div>
            </div>
        </div>

        <div class="cr-input-field">
            <label for="cr_pub_address">Địa chỉ liên hệ</label>
            <div class="cr-input-wrap">
                <span class="cr-input-icon">📍</span>
                <input type="text" id="cr_pub_address" name="address" placeholder="Tỉnh / Thành phố, Quận / Huyện..." />
            </div>
        </div>

        <div class="cr-input-field">
            <label for="cr_pub_note">Ghi chú / Yêu cầu thêm</label>
            <div class="cr-input-wrap">
                <textarea id="cr_pub_note" name="note" rows="3" placeholder="Nhập nội dung lời nhắn hoặc thời gian thuận tiện để gọi lại..."></textarea>
            </div>
        </div>

        <div class="cr-form-submit-wrap">
            <button type="submit" id="cr-btn-submit-registration" class="cr-submit-btn">
                <span class="cr-btn-text">Gửi Thông Tin Đăng Ký</span>
                <span class="cr-btn-spinner" style="display: none;">⏳ Đang gửi...</span>
            </button>
        </div>
    </form>
</div>
