jQuery(document).ready(function ($) {
    'use strict';

    var $form = $('#cr-public-registration-form');
    if (!$form.length) return;

    $form.on('submit', function (e) {
        e.preventDefault();

        var $msgBox = $form.find('.cr-form-response-msg');
        var $submitBtn = $('#cr-btn-submit-registration');
        var $btnText = $submitBtn.find('.cr-btn-text');
        var $btnSpinner = $submitBtn.find('.cr-btn-spinner');

        // Reset response box
        $msgBox.removeClass('cr-success cr-error').hide().text('');

        // Basic Client Validation
        var fullname = $.trim($('#cr_pub_fullname').val());
        var phone = $.trim($('#cr_pub_phone').val());

        if (!fullname) {
            showMsg('Vui lòng nhập Họ và tên của bạn.', 'cr-error');
            $('#cr_pub_fullname').focus();
            return;
        }

        if (!phone) {
            showMsg('Vui lòng nhập Số điện thoại liên hệ.', 'cr-error');
            $('#cr_pub_phone').focus();
            return;
        }

        // Show loading spinner
        $submitBtn.prop('disabled', true);
        $btnText.hide();
        $btnSpinner.show();

        var formData = $form.serializeArray();
        formData.push({ name: 'action', value: 'cr_submit_registration' });
        formData.push({ name: 'nonce', value: crPublic.nonce });

        $.ajax({
            url: crPublic.ajax_url,
            type: 'POST',
            data: formData,
            success: function (res) {
                $submitBtn.prop('disabled', false);
                $btnSpinner.hide();
                $btnText.show();

                if (res.success) {
                    showMsg(res.data.message, 'cr-success');
                    $form[0].reset();
                } else {
                    showMsg(res.data.message || 'Có lỗi xảy ra, vui lòng thử lại.', 'cr-error');
                }
            },
            error: function () {
                $submitBtn.prop('disabled', false);
                $btnSpinner.hide();
                $btnText.show();

                showMsg('Không thể kết nối đến máy chủ. Vui lòng thử lại sau!', 'cr-error');
            }
        });

        function showMsg(text, typeClass) {
            $msgBox.addClass(typeClass).text(text).fadeIn(200);
        }
    });
});
