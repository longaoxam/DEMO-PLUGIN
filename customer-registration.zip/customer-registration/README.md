# Plugin Đăng Ký & Quản Lý Thông Tin Khách Hàng (WordPress)

Plugin WordPress chuyên nghiệp cho phép tiếp nhận thông tin đăng ký tư vấn/dịch vụ từ khách hàng phía Frontend và cung cấp Dashboard quản trị hiện đại, toàn diện trong Admin.

---

## 🚀 Tính năng nổi bật

### 1. **Form Đăng Ký Frontend (Public)**
- Hiển thị thông qua Shortcode: `[dang_ky_khach_hang]`.
- Giao diện thiết kế đẹp mắt, chuẩn Responsive (mobile & desktop).
- Gửi dữ liệu không cần tải lại trang (tích hợp **AJAX**).
- Kiểm tra hợp lệ dữ liệu (Validation) thời gian thực.
- Gửi mail tự động thông báo tới Email Admin khi có đăng ký mới.

### 2. **Dashboard Quản Lý Khách Hàng (Admin)**
- Menu **Quản lý Khách hàng** được thêm trực tiếp vào menu chính WordPress Admin.
- **Thống kê KPI**: Thẻ thống kê trực quan (Tổng số khách hàng, Mới hôm nay, Chờ xử lý, Đã liên hệ, Hoàn thành).
- **Bộ lọc & Tìm kiếm**: Tìm kiếm nhanh theo Họ tên, SĐT, Email, Nhu cầu và Lọc theo trạng thái xử lý.
- **Quản lý CRUD**:
  - Xem và chỉnh sửa thông tin chi tiết qua Modal Popup.
  - Cập nhật trạng thái xử lý nhanh (Chờ xử lý, Đã liên hệ, Hoàn thành, Đã hủy) ngay tại bảng.
  - Xóa khách hàng với xác nhận an toàn.
  - Thêm mới khách hàng thủ công trực tiếp từ Admin.
- **Xuất dữ liệu CSV**: Nút xuất danh sách khách hàng ra file CSV chuẩn mã hóa UTF-8 BOM (không lỗi font Tiếng Việt trên MS Excel).

---

## 📦 Hướng Dẫn Cài Đặt

1. Nén thư mục `customer-registration` thành file `customer-registration.zip`.
2. Truy cập vào WordPress Admin -> **Plugins (Gói mở rộng)** -> **Add New (Thêm mới)** -> **Upload Plugin (Tải plugin lên)**.
3. Chọn file `customer-registration.zip` và nhấn **Install Now (Cài đặt ngay)**.
4. Nhấn **Activate (Kích hoạt)** plugin.

---

## 💻 Hướng Dẫn Sử Dụng

### 1. Hiển thị Form Đăng Ký phía Khách hàng
Chèn đoạn shortcode sau vào bất kỳ Trang (Page), Bài viết (Post) hoặc Widget nào:

```html
[dang_ky_khach_hang]
```

### 2. Quản lý danh sách trong Admin
- Đăng nhập WordPress Admin -> Truy cập Menu **Quản lý Khách hàng** ở thanh menu bên trái.
- Tại đây bạn có thể xem danh sách, lọc dữ liệu, sửa/xóa hoặc xuất file CSV báo cáo.

---

## 🔒 Bảo Mật & Chuẩn WordPress
- Sử dụng **WordPress Nonce** chống tấn công CSRF.
- Đầy đủ hàm **Sanitization** & **Escaping** chống SQL Injection và XSS.
- Sử dụng `dbDelta` chuẩn WordPress cho việc tạo bảng CSDL.
