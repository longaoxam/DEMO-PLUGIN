<?php
/**
 * Plugin Name: Đăng ký & Quản lý Thông tin Khách hàng
 * Plugin URI: https://example.com/customer-registration
 * Description: Plugin chuyên nghiệp cho phép khách hàng đăng ký thông tin qua Form Shortcode [dang_ky_khach_hang] và quản lý danh sách trong WordPress Dashboard với tính năng thống kê, lọc, tìm kiếm, sửa/xóa và xuất CSV.
 * Version: 1.0.0
 * Author: Antigravity AI
 * Text Domain: customer-registration
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define Plugin Constants
define('CR_VERSION', '1.0.0');
define('CR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CR_PLUGIN_FILE', __FILE__);

// Include Required Classes
require_once CR_PLUGIN_DIR . 'includes/class-db.php';
require_once CR_PLUGIN_DIR . 'includes/class-admin.php';
require_once CR_PLUGIN_DIR . 'includes/class-public.php';

/**
 * Main Plugin Class
 */
class Customer_Registration_Plugin {
    
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Register Activation Hook
        register_activation_hook(CR_PLUGIN_FILE, array($this, 'activate'));
        
        // Initialize Core Components
        add_action('plugins_loaded', array($this, 'init'));
    }

    public function activate() {
        CR_DB::create_table();
    }

    public function init() {
        // Initialize Admin Manager
        if (is_admin()) {
            new CR_Admin();
        }

        // Initialize Public Registration Form
        new CR_Public();
    }
}

// Instantiate Plugin
Customer_Registration_Plugin::get_instance();
