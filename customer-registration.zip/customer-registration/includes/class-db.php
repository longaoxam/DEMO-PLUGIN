<?php
/**
 * Database Handler for Customer Registration Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class CR_DB {

    public static function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'customer_registrations';
    }

    /**
     * Create custom database table on plugin activation
     */
    public static function create_table() {
        global $wpdb;
        $table_name = self::get_table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            fullname VARCHAR(191) NOT NULL,
            phone VARCHAR(50) NOT NULL,
            email VARCHAR(191) NOT NULL,
            address TEXT NULL,
            service_needed VARCHAR(191) NULL,
            note TEXT NULL,
            status VARCHAR(50) NOT NULL DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Fetch list of customers with search, status filter, limit, offset
     */
    public static function get_customers($args = array()) {
        global $wpdb;
        $table_name = self::get_table_name();

        $defaults = array(
            'search'    => '',
            'status'    => '',
            'orderby'   => 'created_at',
            'order'     => 'DESC',
            'number'    => 20,
            'offset'    => 0,
        );

        $r = wp_parse_args($args, $defaults);

        $where = array('1=1');
        $values = array();

        if (!empty($r['search'])) {
            $search_like = '%' . $wpdb->esc_like($r['search']) . '%';
            $where[] = "(fullname LIKE %s OR phone LIKE %s OR email LIKE %s OR service_needed LIKE %s)";
            $values[] = $search_like;
            $values[] = $search_like;
            $values[] = $search_like;
            $values[] = $search_like;
        }

        if (!empty($r['status']) && $r['status'] !== 'all') {
            $where[] = "status = %s";
            $values[] = $r['status'];
        }

        $where_clause = implode(' AND ', $where);

        $valid_orderby = array('id', 'fullname', 'phone', 'email', 'status', 'created_at');
        $orderby = in_array($r['orderby'], $valid_orderby) ? $r['orderby'] : 'created_at';
        $order = strtoupper($r['order']) === 'ASC' ? 'ASC' : 'DESC';

        $query = "SELECT * FROM $table_name WHERE $where_clause ORDER BY $orderby $order";

        if ($r['number'] > 0) {
            $query .= " LIMIT %d OFFSET %d";
            $values[] = (int) $r['number'];
            $values[] = (int) $r['offset'];
        }

        if (!empty($values)) {
            $prepared = $wpdb->prepare($query, $values);
            return $wpdb->get_results($prepared, ARRAY_A);
        }

        return $wpdb->get_results($query, ARRAY_A);
    }

    /**
     * Get total customer count with filters
     */
    public static function get_total_count($args = array()) {
        global $wpdb;
        $table_name = self::get_table_name();

        $where = array('1=1');
        $values = array();

        if (!empty($args['search'])) {
            $search_like = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = "(fullname LIKE %s OR phone LIKE %s OR email LIKE %s OR service_needed LIKE %s)";
            $values[] = $search_like;
            $values[] = $search_like;
            $values[] = $search_like;
            $values[] = $search_like;
        }

        if (!empty($args['status']) && $args['status'] !== 'all') {
            $where[] = "status = %s";
            $values[] = $args['status'];
        }

        $where_clause = implode(' AND ', $where);
        $query = "SELECT COUNT(*) FROM $table_name WHERE $where_clause";

        if (!empty($values)) {
            return (int) $wpdb->get_var($wpdb->prepare($query, $values));
        }

        return (int) $wpdb->get_var($query);
    }

    /**
     * Get single customer by ID
     */
    public static function get_customer($id) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id), ARRAY_A);
    }

    /**
     * Insert new customer
     */
    public static function insert_customer($data) {
        global $wpdb;
        $table_name = self::get_table_name();

        $insert_data = array(
            'fullname'       => sanitize_text_field($data['fullname']),
            'phone'          => sanitize_text_field($data['phone']),
            'email'          => sanitize_email($data['email']),
            'address'        => isset($data['address']) ? sanitize_textarea_field($data['address']) : '',
            'service_needed' => isset($data['service_needed']) ? sanitize_text_field($data['service_needed']) : '',
            'note'           => isset($data['note']) ? sanitize_textarea_field($data['note']) : '',
            'status'         => isset($data['status']) ? sanitize_text_field($data['status']) : 'pending',
            'created_at'     => current_time('mysql'),
        );

        $inserted = $wpdb->insert($table_name, $insert_data);
        if ($inserted) {
            return $wpdb->insert_id;
        }
        return false;
    }

    /**
     * Update customer
     */
    public static function update_customer($id, $data) {
        global $wpdb;
        $table_name = self::get_table_name();

        $update_data = array();
        if (isset($data['fullname'])) $update_data['fullname'] = sanitize_text_field($data['fullname']);
        if (isset($data['phone'])) $update_data['phone'] = sanitize_text_field($data['phone']);
        if (isset($data['email'])) $update_data['email'] = sanitize_email($data['email']);
        if (isset($data['address'])) $update_data['address'] = sanitize_textarea_field($data['address']);
        if (isset($data['service_needed'])) $update_data['service_needed'] = sanitize_text_field($data['service_needed']);
        if (isset($data['note'])) $update_data['note'] = sanitize_textarea_field($data['note']);
        if (isset($data['status'])) $update_data['status'] = sanitize_text_field($data['status']);

        if (empty($update_data)) {
            return false;
        }

        return $wpdb->update($table_name, $update_data, array('id' => (int) $id));
    }

    /**
     * Delete customer
     */
    public static function delete_customer($id) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->delete($table_name, array('id' => (int) $id));
    }

    /**
     * Get summary stats for dashboard
     */
    public static function get_stats() {
        global $wpdb;
        $table_name = self::get_table_name();

        $today = current_time('Y-m-d');

        $total     = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        $pending   = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'pending'");
        $contacted = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'contacted'");
        $completed = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'completed'");
        $cancelled = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'cancelled'");
        $today_cnt = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE DATE(created_at) = %s", $today));

        return array(
            'total'     => $total,
            'pending'   => $pending,
            'contacted' => $contacted,
            'completed' => $completed,
            'cancelled' => $cancelled,
            'today'     => $today_cnt,
        );
    }
}
