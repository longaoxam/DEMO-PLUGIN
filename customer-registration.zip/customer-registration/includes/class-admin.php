<?php
/**
 * Admin Area Class for Customer Registration Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class CR_Admin {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // AJAX hooks
        add_action('wp_ajax_cr_get_customer', array($this, 'ajax_get_customer'));
        add_action('wp_ajax_cr_save_customer', array($this, 'ajax_save_customer'));
        add_action('wp_ajax_cr_delete_customer', array($this, 'ajax_delete_customer'));
        add_action('wp_ajax_cr_update_status', array($this, 'ajax_update_status'));

        // Export CSV hook
        add_action('admin_post_cr_export_csv', array($this, 'export_csv'));
    }

    /**
     * Add menu dashboard page
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Quản lý Khách hàng', 'customer-registration'),
            __('Quản lý Khách hàng', 'customer-registration'),
            'manage_options',
            'customer-registration',
            array($this, 'render_dashboard'),
            'dashicons-groups',
            26
        );
    }

    /**
     * Enqueue styles and scripts for admin
     */
    public function enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_customer-registration') {
            return;
        }

        wp_enqueue_style(
            'cr-admin-css',
            CR_PLUGIN_URL . 'admin/css/admin-style.css',
            array(),
            CR_VERSION
        );

        wp_enqueue_script(
            'cr-admin-js',
            CR_PLUGIN_URL . 'admin/js/admin-script.js',
            array('jquery'),
            CR_VERSION,
            true
        );

        wp_localize_script('cr-admin-js', 'crAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('cr_admin_nonce'),
            'i18n'     => array(
                'confirm_delete' => __('Bạn có chắc chắn muốn xóa khách hàng này không?', 'customer-registration'),
                'error_generic'  => __('Có lỗi xảy ra, vui lòng thử lại!', 'customer-registration'),
            )
        ));
    }

    /**
     * Render Main Dashboard View
     */
    public function render_dashboard() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Bạn không có quyền truy cập trang này.', 'customer-registration'));
        }

        // Include view template
        require_once CR_PLUGIN_DIR . 'admin/views/dashboard-page.php';
        require_once CR_PLUGIN_DIR . 'admin/views/customer-modal.php';
    }

    /**
     * AJAX: Get single customer data
     */
    public function ajax_get_customer() {
        check_ajax_referer('cr_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $customer = CR_DB::get_customer($id);

        if ($customer) {
            wp_send_json_success($customer);
        } else {
            wp_send_json_error(array('message' => 'Không tìm thấy khách hàng.'));
        }
    }

    /**
     * AJAX: Save/Update customer
     */
    public function ajax_save_customer() {
        check_ajax_referer('cr_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $fullname = isset($_POST['fullname']) ? sanitize_text_field($_POST['fullname']) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $address = isset($_POST['address']) ? sanitize_textarea_field($_POST['address']) : '';
        $service_needed = isset($_POST['service_needed']) ? sanitize_text_field($_POST['service_needed']) : '';
        $note = isset($_POST['note']) ? sanitize_textarea_field($_POST['note']) : '';
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'pending';

        if (empty($fullname) || empty($phone)) {
            wp_send_json_error(array('message' => 'Họ tên và Số điện thoại là bắt buộc.'));
        }

        $data = array(
            'fullname'       => $fullname,
            'phone'          => $phone,
            'email'          => $email,
            'address'        => $address,
            'service_needed' => $service_needed,
            'note'           => $note,
            'status'         => $status
        );

        if ($id > 0) {
            $updated = CR_DB::update_customer($id, $data);
            if ($updated !== false) {
                wp_send_json_success(array('message' => 'Cập nhật khách hàng thành công!'));
            } else {
                wp_send_json_error(array('message' => 'Lỗi khi cập nhật dữ liệu.'));
            }
        } else {
            $new_id = CR_DB::insert_customer($data);
            if ($new_id) {
                wp_send_json_success(array('message' => 'Thêm khách hàng thành công!'));
            } else {
                wp_send_json_error(array('message' => 'Lỗi khi thêm mới khách hàng.'));
            }
        }
    }

    /**
     * AJAX: Delete customer
     */
    public function ajax_delete_customer() {
        check_ajax_referer('cr_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ($id <= 0) {
            wp_send_json_error(array('message' => 'ID không hợp lệ.'));
        }

        $deleted = CR_DB::delete_customer($id);
        if ($deleted) {
            wp_send_json_success(array('message' => 'Đã xóa khách hàng thành công!'));
        } else {
            wp_send_json_error(array('message' => 'Không thể xóa khách hàng.'));
        }
    }

    /**
     * AJAX: Quick Update Status
     */
    public function ajax_update_status() {
        check_ajax_referer('cr_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
        }

        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if ($id <= 0 || empty($status)) {
            wp_send_json_error(array('message' => 'Dữ liệu không hợp lệ.'));
        }

        $updated = CR_DB::update_customer($id, array('status' => $status));
        if ($updated !== false) {
            wp_send_json_success(array('message' => 'Cập nhật trạng thái thành công!'));
        } else {
            wp_send_json_error(array('message' => 'Cập nhật thất bại.'));
        }
    }

    /**
     * Export Customer Data to CSV File
     */
    public function export_csv() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized access');
        }

        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'cr_export_nonce')) {
            wp_die('Invalid nonce');
        }

        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';

        $customers = CR_DB::get_customers(array(
            'search' => $search,
            'status' => $status,
            'number' => -1 // fetch all
        ));

        $filename = 'danh-sach-khach-hang-' . date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);

        $output = fopen('php://output', 'w');

        // UTF-8 BOM for Excel compatibility
        fputs($output, "\xEF\xBB\xBF");

        // Header Row
        fputcsv($output, array(
            'ID',
            'Họ và tên',
            'Số điện thoại',
            'Email',
            'Địa chỉ',
            'Dịch vụ / Nhu cầu',
            'Ghi chú',
            'Trạng thái',
            'Ngày đăng ký'
        ));

        $status_labels = array(
            'pending'   => 'Chờ xử lý',
            'contacted' => 'Đã liên hệ',
            'completed' => 'Hoàn thành',
            'cancelled' => 'Đã hủy',
        );

        if (!empty($customers)) {
            foreach ($customers as $customer) {
                $st_text = isset($status_labels[$customer['status']]) ? $status_labels[$customer['status']] : $customer['status'];

                fputcsv($output, array(
                    $customer['id'],
                    $customer['fullname'],
                    $customer['phone'],
                    $customer['email'],
                    $customer['address'],
                    $customer['service_needed'],
                    $customer['note'],
                    $st_text,
                    $customer['created_at']
                ));
            }
        }

        fclose($output);
        exit;
    }
}
