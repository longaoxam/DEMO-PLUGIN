<?php
/**
 * Public Area Handler for Customer Registration Form
 */

if (!defined('ABSPATH')) {
    exit;
}

class CR_Public {

    public function __construct() {
        // Shortcode
        add_shortcode('dang_ky_khach_hang', array($this, 'render_shortcode'));

        // Enqueue Public Assets
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));

        // Frontend Submission AJAX Hooks
        add_action('wp_ajax_cr_submit_registration', array($this, 'ajax_submit_registration'));
        add_action('wp_ajax_nopriv_cr_submit_registration', array($this, 'ajax_submit_registration'));
    }

    /**
     * Enqueue CSS & JS on public pages
     */
    public function enqueue_assets() {
        wp_enqueue_style(
            'cr-public-css',
            CR_PLUGIN_URL . 'public/css/public-style.css',
            array(),
            CR_VERSION
        );

        wp_enqueue_script(
            'cr-public-js',
            CR_PLUGIN_URL . 'public/js/public-script.js',
            array('jquery'),
            CR_VERSION,
            true
        );

        wp_localize_script('cr-public-js', 'crPublic', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('cr_public_nonce'),
        ));
    }

    /**
     * Shortcode callback [dang_ky_khach_hang]
     */
    public function render_shortcode($atts) {
        ob_start();
        require CR_PLUGIN_DIR . 'public/views/registration-form.php';
        return ob_get_clean();
    }

    /**
     * AJAX submission callback
     */
    public function ajax_submit_registration() {
        check_ajax_referer('cr_public_nonce', 'nonce');

        $fullname       = isset($_POST['fullname']) ? sanitize_text_field($_POST['fullname']) : '';
        $phone          = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $email          = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $address        = isset($_POST['address']) ? sanitize_textarea_field($_POST['address']) : '';
        $service_needed = isset($_POST['service_needed']) ? sanitize_text_field($_POST['service_needed']) : '';
        $note           = isset($_POST['note']) ? sanitize_textarea_field($_POST['note']) : '';

        // Validation
        if (empty($fullname)) {
            wp_send_json_error(array('message' => 'Vui lòng nhập Họ và tên của bạn.'));
        }

        if (empty($phone)) {
            wp_send_json_error(array('message' => 'Vui lòng nhập Số điện thoại liên hệ.'));
        }

        // Basic phone format validation (numeric & min 9 chars)
        $clean_phone = preg_replace('/[^0-9+]/', '', $phone);
        if (strlen($clean_phone) < 9) {
            wp_send_json_error(array('message' => 'Số điện thoại không hợp lệ, vui lòng kiểm tra lại.'));
        }

        if (!empty($email) && !is_email($email)) {
            wp_send_json_error(array('message' => 'Địa chỉ Email không đúng định dạng.'));
        }

        $data = array(
            'fullname'       => $fullname,
            'phone'          => $phone,
            'email'          => $email,
            'address'        => $address,
            'service_needed' => $service_needed,
            'note'           => $note,
            'status'         => 'pending'
        );

        $inserted_id = CR_DB::insert_customer($data);

        if ($inserted_id) {
            // Send optional admin email notification if wp_mail works
            $admin_email = get_option('admin_email');
            $subject = '[Đăng ký mới] Thông tin từ ' . $fullname;
            $body  = "Bạn nhận được thông tin đăng ký tư vấn mới:\n\n";
            $body .= "Họ tên: " . $fullname . "\n";
            $body .= "SĐT: " . $phone . "\n";
            $body .= "Email: " . $email . "\n";
            $body .= "Dịch vụ quan tâm: " . $service_needed . "\n";
            $body .= "Địa chỉ: " . $address . "\n";
            $body .= "Ghi chú: " . $note . "\n\n";
            $body .= "Quản lý tại Dashboard: " . admin_url('admin.php?page=customer-registration');

            @wp_mail($admin_email, $subject, $body);

            wp_send_json_success(array(
                'message' => 'Cảm ơn bạn đã đăng ký! Chúng tôi sẽ liên hệ lại trong thời gian sớm nhất.'
            ));
        } else {
            wp_send_json_error(array('message' => 'Có lỗi xảy ra khi lưu thông tin. Vui lòng thử lại sau.'));
        }
    }
}
