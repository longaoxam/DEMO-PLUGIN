jQuery(document).ready(function ($) {
    'use strict';

    var $modal = $('#cr-customer-modal');
    var $form = $('#cr-customer-form');

    // Open Add Customer Modal
    $('#cr-btn-add-customer').on('click', function (e) {
        e.preventDefault();
        $form[0].reset();
        $('#cr_field_id').val(0);
        $('#cr-modal-title').html('<span class="dashicons dashicons-plus-alt2"></span> Thêm Khách Hàng Mới');
        $modal.fadeIn(200);
    });

    // Close Modal
    $('.cr-modal-close, .cr-modal-close-btn').on('click', function () {
        $modal.fadeOut(200);
    });

    // Close modal on background click
    $modal.on('click', function (e) {
        if ($(e.target).is('.cr-modal-overlay')) {
            $modal.fadeOut(200);
        }
    });

    // Edit Customer Button Click
    $(document).on('click', '.cr-btn-edit', function (e) {
        e.preventDefault();
        var id = $(this).data('id');
        if (!id) return;

        $('#cr-modal-title').html('<span class="dashicons dashicons-edit"></span> Đang tải dữ liệu...');
        $modal.fadeIn(200);

        $.ajax({
            url: crAdmin.ajax_url,
            type: 'POST',
            data: {
                action: 'cr_get_customer',
                nonce: crAdmin.nonce,
                id: id
            },
            success: function (res) {
                if (res.success) {
                    var data = res.data;
                    $('#cr_field_id').val(data.id);
                    $('#cr_field_fullname').val(data.fullname);
                    $('#cr_field_phone').val(data.phone);
                    $('#cr_field_email').val(data.email);
                    $('#cr_field_address').val(data.address);
                    $('#cr_field_service_needed').val(data.service_needed);
                    $('#cr_field_note').val(data.note);
                    $('#cr_field_status').val(data.status);

                    $('#cr-modal-title').html('<span class="dashicons dashicons-edit"></span> Chỉnh Sửa Khách Hàng #' + data.id);
                } else {
                    alert(res.data.message || crAdmin.i18n.error_generic);
                    $modal.fadeOut(200);
                }
            },
            error: function () {
                alert(crAdmin.i18n.error_generic);
                $modal.fadeOut(200);
            }
        });
    });

    // Save/Update Customer Form Submit
    $form.on('submit', function (e) {
        e.preventDefault();

        var $submitBtn = $('#cr-btn-save-customer');
        var originalText = $submitBtn.html();
        $submitBtn.prop('disabled', true).text('Đang lưu...');

        var formData = $form.serializeArray();
        formData.push({ name: 'action', value: 'cr_save_customer' });
        formData.push({ name: 'nonce', value: crAdmin.nonce });

        $.ajax({
            url: crAdmin.ajax_url,
            type: 'POST',
            data: formData,
            success: function (res) {
                $submitBtn.prop('disabled', false).html(originalText);
                if (res.success) {
                    $modal.fadeOut(200);
                    window.location.reload();
                } else {
                    alert(res.data.message || crAdmin.i18n.error_generic);
                }
            },
            error: function () {
                $submitBtn.prop('disabled', false).html(originalText);
                alert(crAdmin.i18n.error_generic);
            }
        });
    });

    // Delete Customer
    $(document).on('click', '.cr-btn-delete', function (e) {
        e.preventDefault();
        var id = $(this).data('id');
        if (!id) return;

        if (!confirm(crAdmin.i18n.confirm_delete)) {
            return;
        }

        var $row = $('#customer-row-' + id);

        $.ajax({
            url: crAdmin.ajax_url,
            type: 'POST',
            data: {
                action: 'cr_delete_customer',
                nonce: crAdmin.nonce,
                id: id
            },
            success: function (res) {
                if (res.success) {
                    $row.fadeOut(300, function () {
                        $(this).remove();
                    });
                } else {
                    alert(res.data.message || crAdmin.i18n.error_generic);
                }
            },
            error: function () {
                alert(crAdmin.i18n.error_generic);
            }
        });
    });

    // Change Status Inline Select
    $(document).on('change', '.cr-status-select', function () {
        var $select = $(this);
        var id = $select.data('id');
        var newStatus = $select.val();

        $select.removeClass('status-badge-pending status-badge-contacted status-badge-completed status-badge-cancelled');
        $select.addClass('status-badge-' + newStatus);

        $.ajax({
            url: crAdmin.ajax_url,
            type: 'POST',
            data: {
                action: 'cr_update_status',
                nonce: crAdmin.nonce,
                id: id,
                status: newStatus
            },
            success: function (res) {
                if (!res.success) {
                    alert(res.data.message || crAdmin.i18n.error_generic);
                }
            },
            error: function () {
                alert(crAdmin.i18n.error_generic);
            }
        });
    });
});
