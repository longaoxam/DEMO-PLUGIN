<?php
/**
 * Admin Dashboard View
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get Filters & Pagination Parameters
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$status = isset($_GET['status_filter']) ? sanitize_text_field($_GET['status_filter']) : 'all';

$per_page = 15;
$offset = ($current_page - 1) * $per_page;

// Fetch Data & Stats
$stats = CR_DB::get_stats();

$args = array(
    'search' => $search,
    'status' => $status,
    'number' => $per_page,
    'offset' => $offset,
    'orderby' => 'created_at',
    'order'   => 'DESC'
);

$customers = CR_DB::get_customers($args);
$total_items = CR_DB::get_total_count($args);
$total_pages = ceil($total_items / $per_page);

$export_nonce = wp_create_nonce('cr_export_nonce');
$export_url = admin_url('admin-post.php?action=cr_export_csv&_wpnonce=' . $export_nonce . '&search=' . urlencode($search) . '&status=' . urlencode($status));
?>

<div class="wrap cr-admin-wrap">
    <!-- Header -->
    <div class="cr-header-banner">
        <div class="cr-header-title">
            <h1><span class="dashicons dashicons-groups"></span> Quản lý Khách Hàng</h1>
            <p>Hệ thống tiếp nhận, theo dõi và quản lý thông tin khách hàng đăng ký tư vấn</p>
        </div>
        <div class="cr-header-actions">
            <button id="cr-btn-add-customer" class="button button-primary button-hero">
                <span class="dashicons dashicons-plus-alt2"></span> Thêm Khách Hàng Mới
            </button>
            <a href="<?php echo esc_url($export_url); ?>" class="button button-secondary button-hero">
                <span class="dashicons dashicons-download"></span> Xuất CSV
            </a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="cr-stats-grid">
        <div class="cr-stat-card cr-stat-total">
            <div class="cr-stat-icon"><span class="dashicons dashicons-id"></span></div>
            <div class="cr-stat-info">
                <span class="cr-stat-value"><?php echo esc_html($stats['total']); ?></span>
                <span class="cr-stat-label">Tổng Khách Hàng</span>
            </div>
        </div>

        <div class="cr-stat-card cr-stat-today">
            <div class="cr-stat-icon"><span class="dashicons dashicons-calendar-alt"></span></div>
            <div class="cr-stat-info">
                <span class="cr-stat-value"><?php echo esc_html($stats['today']); ?></span>
                <span class="cr-stat-label">Mới Hôm Nay</span>
            </div>
        </div>

        <div class="cr-stat-card cr-stat-pending">
            <div class="cr-stat-icon"><span class="dashicons dashicons-clock"></span></div>
            <div class="cr-stat-info">
                <span class="cr-stat-value"><?php echo esc_html($stats['pending']); ?></span>
                <span class="cr-stat-label">Chờ Xử Lý</span>
            </div>
        </div>

        <div class="cr-stat-card cr-stat-contacted">
            <div class="cr-stat-icon"><span class="dashicons dashicons-phone"></span></div>
            <div class="cr-stat-info">
                <span class="cr-stat-value"><?php echo esc_html($stats['contacted']); ?></span>
                <span class="cr-stat-label">Đã Liên Hệ</span>
            </div>
        </div>

        <div class="cr-stat-card cr-stat-completed">
            <div class="cr-stat-icon"><span class="dashicons dashicons-yes-alt"></span></div>
            <div class="cr-stat-info">
                <span class="cr-stat-value"><?php echo esc_html($stats['completed']); ?></span>
                <span class="cr-stat-label">Hoàn Thành</span>
            </div>
        </div>
    </div>

    <!-- Filter & Search Toolbar -->
    <div class="cr-toolbar-box">
        <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="cr-filter-form">
            <input type="hidden" name="page" value="customer-registration" />

            <div class="cr-form-group search-group">
                <span class="dashicons dashicons-search"></span>
                <input type="text" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Tìm tên, SĐT, Email, Dịch vụ..." />
            </div>

            <div class="cr-form-group select-group">
                <select name="status_filter">
                    <option value="all" <?php selected($status, 'all'); ?>>-- Tất cả trạng thái --</option>
                    <option value="pending" <?php selected($status, 'pending'); ?>>Chờ xử lý</option>
                    <option value="contacted" <?php selected($status, 'contacted'); ?>>Đã liên hệ</option>
                    <option value="completed" <?php selected($status, 'completed'); ?>>Hoàn thành</option>
                    <option value="cancelled" <?php selected($status, 'cancelled'); ?>>Đã hủy</option>
                </select>
            </div>

            <button type="submit" class="button button-secondary">Lọc dữ liệu</button>
            <?php if (!empty($search) || $status !== 'all'): ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=customer-registration')); ?>" class="button">Xóa bộ lọc</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Customer Table -->
    <div class="cr-table-container">
        <table class="wp-list-table widefat fixed striped customers-table">
            <thead>
                <tr>
                    <th style="width: 50px;">ID</th>
                    <th style="width: 180px;">Họ & Tên</th>
                    <th style="width: 190px;">Liên hệ</th>
                    <th style="width: 160px;">Nhu cầu / Dịch vụ</th>
                    <th>Địa chỉ & Ghi chú</th>
                    <th style="width: 140px;">Trạng thái</th>
                    <th style="width: 150px;">Ngày đăng ký</th>
                    <th style="width: 120px;" class="text-right">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($customers)): ?>
                    <?php foreach ($customers as $c): ?>
                        <tr id="customer-row-<?php echo intval($c['id']); ?>">
                            <td><strong>#<?php echo intval($c['id']); ?></strong></td>
                            <td>
                                <strong class="cr-customer-name"><?php echo esc_html($c['fullname']); ?></strong>
                            </td>
                            <td>
                                <div class="cr-contact-info">
                                    <span><span class="dashicons dashicons-phone"></span> <?php echo esc_html($c['phone']); ?></span>
                                    <?php if (!empty($c['email'])): ?>
                                        <small><span class="dashicons dashicons-email"></span> <?php echo esc_html($c['email']); ?></small>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="cr-service-tag"><?php echo !empty($c['service_needed']) ? esc_html($c['service_needed']) : '---'; ?></span>
                            </td>
                            <td>
                                <div class="cr-address-note">
                                    <?php if (!empty($c['address'])): ?>
                                        <p class="cr-addr"><strong>Đ/c:</strong> <?php echo esc_html($c['address']); ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($c['note'])): ?>
                                        <p class="cr-note"><em>Ghi chú: <?php echo esc_html($c['note']); ?></em></p>
                                    <?php endif; ?>
                                    <?php if (empty($c['address']) && empty($c['note'])): ?>
                                        <span class="text-muted">Không có</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <select class="cr-status-select status-badge-<?php echo esc_attr($c['status']); ?>" data-id="<?php echo intval($c['id']); ?>">
                                    <option value="pending" <?php selected($c['status'], 'pending'); ?>>Chờ xử lý</option>
                                    <option value="contacted" <?php selected($c['status'], 'contacted'); ?>>Đã liên hệ</option>
                                    <option value="completed" <?php selected($c['status'], 'completed'); ?>>Hoàn thành</option>
                                    <option value="cancelled" <?php selected($c['status'], 'cancelled'); ?>>Đã hủy</option>
                                </select>
                            </td>
                            <td>
                                <span class="cr-date"><?php echo esc_html(date('H:i d/m/Y', strtotime($c['created_at']))); ?></span>
                            </td>
                            <td class="text-right">
                                <button class="button button-small cr-btn-edit" data-id="<?php echo intval($c['id']); ?>" title="Xem / Sửa">
                                    <span class="dashicons dashicons-edit"></span>
                                </button>
                                <button class="button button-small button-link-delete cr-btn-delete" data-id="<?php echo intval($c['id']); ?>" title="Xóa">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="cr-empty-state">
                            <span class="dashicons dashicons-info"></span> Chưa có dữ liệu khách hàng nào phù hợp.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <div class="cr-pagination-wrap">
            <span class="displaying-num">Hiển thị <?php echo count($customers); ?> / <?php echo $total_items; ?> mục</span>
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo; Trước',
                    'next_text' => 'Sau &raquo;',
                    'total' => $total_pages,
                    'current' => $current_page
                ));
                ?>
            </div>
        </div>
    <?php endif; ?>
</div>
