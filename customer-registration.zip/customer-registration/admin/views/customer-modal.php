<?php
/**
 * Customer Edit/Add Modal View
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="cr-customer-modal" class="cr-modal-overlay" style="display: none;">
    <div class="cr-modal-container">
        <div class="cr-modal-header">
            <h3 id="cr-modal-title"><span class="dashicons dashicons-edit"></span> Thêm / Sửa Thông tin Khách hàng</h3>
            <button type="button" class="cr-modal-close">&times;</button>
        </div>

        <form id="cr-customer-form">
            <input type="hidden" id="cr_field_id" name="id" value="0" />

            <div class="cr-modal-body">
                <div class="cr-form-row">
                    <div class="cr-field-col">
                        <label for="cr_field_fullname">Họ và tên <span class="required">*</span></label>
                        <input type="text" id="cr_field_fullname" name="fullname" required placeholder="Nhập họ tên khách hàng" />
                    </div>
                    <div class="cr-field-col">
                        <label for="cr_field_phone">Số điện thoại <span class="required">*</span></label>
                        <input type="text" id="cr_field_phone" name="phone" required placeholder="Nhập số điện thoại" />
                    </div>
                </div>

                <div class="cr-form-row">
                    <div class="cr-field-col">
                        <label for="cr_field_email">Địa chỉ Email</label>
                        <input type="email" id="cr_field_email" name="email" placeholder="example@domain.com" />
                    </div>
                    <div class="cr-field-col">
                        <label for="cr_field_status">Trạng thái xử lý</label>
                        <select id="cr_field_status" name="status">
                            <option value="pending">Chờ xử lý</option>
                            <option value="contacted">Đã liên hệ</option>
                            <option value="completed">Hoàn thành</option>
                            <option value="cancelled">Đã hủy</option>
                        </select>
                    </div>
                </div>

                <div class="cr-form-group">
                    <label for="cr_field_service_needed">Dịch vụ / Nhu cầu quan tâm</label>
                    <input type="text" id="cr_field_service_needed" name="service_needed" placeholder="Ví dụ: Thiết kế Website, Tư vấn SEO..." />
                </div>

                <div class="cr-form-group">
                    <label for="cr_field_address">Địa chỉ</label>
                    <input type="text" id="cr_field_address" name="address" placeholder="Địa chỉ liên hệ" />
                </div>

                <div class="cr-form-group">
                    <label for="cr_field_note">Ghi chú nội bộ</label>
                    <textarea id="cr_field_note" name="note" rows="3" placeholder="Nhập ghi chú cho trao đổi hoặc yêu cầu đặc biệt của khách hàng..."></textarea>
                </div>
            </div>

            <div class="cr-modal-footer">
                <button type="button" class="button cr-modal-close-btn">Hủy bỏ</button>
                <button type="submit" id="cr-btn-save-customer" class="button button-primary">
                    <span class="dashicons dashicons-saved"></span> Lưu thay đổi
                </button>
            </div>
        </form>
    </div>
</div>
